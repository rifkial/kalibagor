<?php

namespace Illuminate\Contracts\Session\Middleware;

interface AuthenticatesSessions
{
    //
}
