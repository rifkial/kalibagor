# Laravel DataTables Complete Package

## Change Log

### v9.0.0 - 2022-05-08

- Add Laravel 9 specific support
- Match package major version with the framework
