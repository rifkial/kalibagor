<?php

namespace Yajra\DataTables\Services;

use Yajra\DataTables\Exports\DataTablesCollectionExport;

class DataTablesExportHandler extends DataTablesCollectionExport
{
}
