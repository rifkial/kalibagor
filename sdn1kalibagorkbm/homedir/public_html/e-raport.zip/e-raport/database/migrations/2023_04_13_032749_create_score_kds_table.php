<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('score_kds', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('slug')->nullable();
            $table->enum('type', ['uts', 'uas'])->nullable();
            $table->unsignedInteger('id_school_year')->nullable();
            $table->unsignedBigInteger('id_student_class')->nullable();
            $table->json('assessment_score')->nullable();
            $table->integer('averege_assesment')->nullable();
            $table->json('skill_score')->nullable();
            $table->integer('averege_skill')->nullable();
            $table->integer('score_uas')->nullable();
            $table->integer('score_uts')->nullable();
            $table->integer('final_assesment')->nullable();
            $table->integer('final_skill')->nullable();
            $table->unsignedBigInteger('id_subject_teacher')->nullable();
            $table->unsignedInteger('id_study_class')->nullable();
            $table->tinyInteger('status')->default(1);
            $table->timestamps();
            $table->softDeletes();
        });

        Schema::table('score_kds', function (Blueprint $table) {
            $table->foreign('id_student_class')->references('id')->on('student_classes')->onDelete('cascade');
            $table->foreign('id_subject_teacher')->references('id')->on('subject_teachers')->onDelete('cascade');
            $table->foreign('id_study_class')->references('id')->on('study_classes')->onDelete('cascade');
            $table->foreign('id_school_year')->references('id')->on('school_years')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('score_kds', function (Blueprint $table) {
            $table->dropForeign('score_kds_id_student_class_foreign');
            $table->dropForeign('score_kds_id_subject_teacher_foreign');
            $table->dropForeign('score_kds_id_study_class_foreign');
            $table->dropForeign('score_kds_id_school_year_foreign');
        });

        Schema::dropIfExists('score_kds');
    }
};
