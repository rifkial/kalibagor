


<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no">
<?php
    $setting = json_decode(file_get_contents(storage_path('app/settings.json')), true);
?>
<title><?php echo e(isset($setting['name_application']) ? $setting['name_application'] : 'E-Raport'); ?> - <?php echo e(session('title')); ?>

</title>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
<link rel="icon" type="image/x-icon" href="assets/img/favicon.ico" />
<!-- BEGIN GLOBAL MANDATORY STYLES -->
<link href="https://fonts.googleapis.com/css?family=Quicksand:400,500,600,700&display=swap" rel="stylesheet">
<link href="<?php echo e(asset('asset/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('asset/css/plugins.css')); ?>" rel="stylesheet" type="text/css" />


<style>
    .layout-px-spacing {
        min-height: calc(100vh - 140px) !important;
    }
</style>
<?php echo $__env->yieldPushContent('styles'); ?>
<?php /**PATH /home/sdn1kalibagorkbm/public_html/e-raport/resources/views/layout/admin/v_head.blade.php ENDPATH**/ ?>