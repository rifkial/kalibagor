<div class="sidebar-wrapper sidebar-theme">
    <nav id="sidebar">
        <div class="profile-info">
            <figure class="user-cover-image"></figure>
            <div class="user-info">
                <img src="<?php echo e(Auth::user()->file ? asset(Auth::user()->file) : asset('asset/img/90x90.jpg')); ?>"
                    alt="avatar">
                <h6 class=""><?php echo e(Auth::user()->name); ?></h6>
                <p class="text-capitalize"><?php echo e(session('role')); ?></p>
            </div>
        </div>
        <div class="shadow-bottom"></div>
        <ul class="list-unstyled menu-categories" id="accordionExample">
            <li class="menu">
                <a href="<?php echo e(route('user.dashboard')); ?>" aria-expanded="<?php echo e(Request::is('home*') ? 'true' : 'false'); ?>"
                    class="dropdown-toggle">
                    <div class="">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                            fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                            stroke-linejoin="round">
                            <rect x="3" y="3" width="7" height="7"></rect>
                            <rect x="14" y="3" width="7" height="7"></rect>
                            <rect x="14" y="14" width="7" height="7"></rect>
                            <rect x="3" y="14" width="7" height="7"></rect>
                        </svg>
                        <span> Dashboard</span>
                    </div>
                </a>
            </li>
            <li class="menu">
                <a href="<?php echo e(route('previews.index')); ?>" aria-expanded="<?php echo e(Request::is('preview*') ? 'true' : 'false'); ?>"
                    class="dropdown-toggle">
                    <div class="">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                            fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                            stroke-linejoin="round">
                            <polyline points="6 9 6 2 18 2 18 9"></polyline>
                            <path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2">
                            </path>
                            <rect x="6" y="14" width="12" height="8"></rect>
                        </svg>
                        <span> Cetak Raport</span>
                    </div>
                </a>
            </li>
            <?php if(session('role') == 'student'): ?>
                <li class="menu">
                    <a href="<?php echo e(route('families.index')); ?>"
                        aria-expanded="<?php echo e(Request::is('families*') ? 'true' : 'false'); ?>" class="dropdown-toggle">
                        <div class="">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                                fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                stroke-linejoin="round">
                                <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                                <circle cx="9" cy="7" r="4"></circle>
                                <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                                <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                            </svg>
                            <span> Keluarga</span>
                        </div>
                    </a>
                </li>
            <?php endif; ?>
        </ul>
    </nav>
</div>
<?php /**PATH /home/sdn1kalibagorkbm/public_html/e-raport/resources/views/layout/admin/v_sidebar_user.blade.php ENDPATH**/ ?>