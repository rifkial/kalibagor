<?php $__env->startSection('content'); ?>
    <?php $__env->startPush('styles'); ?>
        <?php echo $__env->make('package.loader.loader_css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('asset/custom/account-setting.css')); ?>">
    <?php $__env->stopPush(); ?>
    <div class="layout-px-spacing">
        <div class="middle-content container-xxl p-0">

            <div class="page-meta mt-3">
                <nav class="breadcrumb-style-one" aria-label="breadcrumb">
                    <ol class="breadcrumb bg-transparent">
                        <li class="breadcrumb-item"><a href="#">User</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('teachers.index')); ?>">Guru</a></li>
                        <li class="breadcrumb-item active" aria-current="page"><?php echo e(isset($teacher) ? 'Edit' : 'Tambah'); ?>

                        </li>
                    </ol>
                </nav>
            </div>
            <div class="row layout-top-spacing">
                <div class="col-lg-12 layout-spacing">
                    <div class="statbox widget box box-shadow">
                        <div class="widget-header">
                            <h4><?php echo e(session('title')); ?></h4>
                        </div>
                        <div class="widget-content widget-content-area">
                            <form
                                action="<?php echo e(route('setting_scores.predicated_scores.storeOrUpdate', ['id' => isset($predicated) ? $predicated->id : null])); ?>"
                                method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="fullName">Predikat</label>
                                    <input type="text" class="form-control"
                                        placeholder="Masukan predikat raport, contoh : A, B"
                                        value="<?php echo e(isset($predicated) ? old('name', $predicated->name) : old('name')); ?>"
                                        name="name">
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <?php
                                    if(isset($predicated)){
                                        $scoreArr = explode('-', $predicated->score);
                                    }
                                ?>
                                <div class="form-row">
                                    <div class="form-group col-md-6">
                                        <label for="inputEmail4">Skor Minimal</label>
                                        <input type="number" name="score[]" class="form-control" required
                                            placeholder="Masukan nilai minimal"
                                            value="<?php echo e(isset($predicated) ? old('score[0]', $scoreArr[0]) : old('score.0')); ?>">
                                        <?php $__errorArgs = ['score.0'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="inputPassword4">Skor Maksimal</label>
                                        <input type="number" class="form-control" name="score[]" required
                                            placeholder="Masukan nilai maksimal"
                                            value="<?php echo e(isset($predicated) ? old('score[1]', $scoreArr[1]) : old('score.1')); ?>">
                                        <?php $__errorArgs = ['score.1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="fullName">Bobot Nilai</label>
                                    <input type="text" class="form-control"
                                        placeholder="Masukan bobot nilai, contoh: 3.6" name="grade_weight"
                                        value="<?php echo e(isset($predicated) ? old('grade_weight', $predicated->grade_weight) : old('grade_weight')); ?>">
                                    <?php $__errorArgs = ['grade_weight'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group">
                                    <label for="fullName">Deskripsi</label>
                                    <textarea name="description" rows="3" class="form-control" placeholder="Masukan deskripsi predikat"><?php echo e(isset($predicated) ? old('description', $predicated->description) : old('description')); ?></textarea>
                                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <button class="btn btn-primary mt-2 d-none" id="btnLoader">
                                    <div class="spinner-grow text-white mr-2 align-self-center loader-sm">
                                        Loading...</div>
                                    Loading
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="account-settings-footer">

            <div class="as-footer-container">

                <button id="multiple-reset" class="btn btn-warning">Reset All</button>
                <div class="blockui-growl-message">
                    <i class="flaticon-double-check"></i>&nbsp; Settings Saved Successfully
                </div>


                <button class="btn btn-primary d-none" id="btnLoader">
                    <div class="spinner-grow text-white mr-2 align-self-center loader-sm">
                        Loading...</div>
                    Loading
                </button>
                <button class="btn btn-primary" id="btnSubmit" onclick="submitForm()">Simpan
                    Data</button>

            </div>

        </div>
    </div>
    <?php $__env->startPush('scripts'); ?>
        <script>
            $(function() {
                $("form").submit(function() {
                    $('#btnLoader').removeClass('d-none');
                    $('#btnSubmit').addClass('d-none');
                });
            });

            function submitForm() {
                $('form').submit();
            }
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin.v_main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sdn1kalibagorkbm/public_html/e-raport/resources/views/content/setting_scores/v_form_predicated_score.blade.php ENDPATH**/ ?>