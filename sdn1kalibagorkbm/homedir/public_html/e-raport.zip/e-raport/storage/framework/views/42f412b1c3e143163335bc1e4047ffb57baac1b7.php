<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>
<script>
    jQuery('.datepickerYear').datepicker({
        format: "yyyy",
        viewMode: "years",
        minViewMode: "years",
        language: "id",
        autoclose: true,
    });
</script>
<?php /**PATH /home/sdn1kalibagorkbm/public_html/e-raport/resources/views/package/datepicker/datepicker_js.blade.php ENDPATH**/ ?>