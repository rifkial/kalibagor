<?php $__env->startSection('content'); ?>
    <?php $__env->startPush('styles'); ?>
        <?php echo $__env->make('package.loader.loader_css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('asset/custom/account-setting.css')); ?>">
    <?php $__env->stopPush(); ?>
    <div class="layout-px-spacing">
        <div class="middle-content container-xxl p-0">

            <div class="page-meta mt-3">
                <nav class="breadcrumb-style-one" aria-label="breadcrumb">
                    <ol class="breadcrumb bg-transparent">
                        <li class="breadcrumb-item"><a href="#">User</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('users.index')); ?>">Siswa</a></li>
                        <li class="breadcrumb-item active" aria-current="page">List</li>
                    </ol>
                </nav>
            </div>

            <div class="row" id="cancel-row">
                <div class="col-xl-12 col-lg-12 col-sm-12 layout-top-spacing layout-spacing">
                    <div class="statbox widget box box-shadow">
                        <div class="widget-header">
                            <h4><?php echo e(session('title')); ?></h4>
                        </div>
                        <form action="<?php echo e(route('attendances.storeOrUpdate')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="widget-content widget-content-area br-8">
                                <div class="table-responsive">

                                    <table class="table table-bordered table-hover">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Siswa</th>
                                                <th>NIS</th>
                                                <th>Sakit</th>
                                                <th>Izin</th>
                                                <th>Alfa</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($index + 1); ?></td>
                                                    <td>
                                                        <div class="d-flex">
                                                            <div class="usr-img-frame mr-2 rounded-circle">
                                                                <img alt="avatar" class="img-fluid rounded-circle"
                                                                    src="<?php echo e($student['file'] != null ? asset($student['file']) : asset('asset/img/90x90.jpg')); ?>">
                                                            </div>
                                                            <p class="align-self-center mb-0 admin-name">
                                                                <?php echo e($student['name']); ?></p>
                                                        </div>
                                                    </td>
                                                    <td><?php echo e($student['nis']); ?></td>
                                                    <input type="hidden" name="id_student_class[]"
                                                        value="<?php echo e($student['id_student_class']); ?>">
                                                    <td>
                                                        <input type="text" class="form-control" name="ill[]"
                                                            value="<?php echo e($student['ill'] != null ? $student['ill'] : '0'); ?>" <?php echo e($student['status_form'] == false ? 'readonly' : ''); ?>>
                                                        <?php $__errorArgs = ['ill.' . $index];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </td>
                                                    <td><input type="text" class="form-control" name="excused[]"
                                                            value="<?php echo e($student['excused'] != null ? $student['excused'] : '0'); ?>" <?php echo e($student['status_form'] == false ? 'readonly' : ''); ?>>
                                                        <?php $__errorArgs = ['excused.' . $index];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </td>
                                                    <td><input type="text" class="form-control" name="unexcused[]"
                                                            value="<?php echo e($student['unexcused'] != null ? $student['unexcused'] : '0'); ?>" <?php echo e($student['status_form'] == false ? 'readonly' : ''); ?>>
                                                        <?php $__errorArgs = ['unexcused.' . $index];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="account-settings-footer">

            <div class="as-footer-container">

                <button id="multiple-reset" class="btn btn-warning">Reset All</button>
                <div class="blockui-growl-message">
                    <i class="flaticon-double-check"></i>&nbsp; Settings Saved Successfully
                </div>
                <button class="btn btn-primary d-none" id="btnLoader">
                    <div class="spinner-grow text-white mr-2 align-self-center loader-sm">
                        Loading...</div>
                    Loading
                </button>
                <button class="btn btn-primary" id="btnSubmit" onclick="submitForm()">Simpan
                    Data</button>

            </div>
        </div>
    </div>
    <?php $__env->startPush('scripts'); ?>
        <script>
            $(document).ready(function() {
                $("form").submit(function() {
                    $('#btnLoader').removeClass('d-none');
                    $('#btnSubmit').addClass('d-none');
                });
            });

            function submitForm() {
                $('form').submit();
            }
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin.v_main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sdn1kalibagorkbm/public_html/e-raport/resources/views/content/attendances/v_attendance.blade.php ENDPATH**/ ?>