<?php $__env->startSection('content'); ?>
    <?php $__env->startPush('styles'); ?>
        <link href="<?php echo e(asset('asset/css/scrollspyNav.css')); ?>" rel="stylesheet" type="text/css" />
    <?php $__env->stopPush(); ?>
    <div class="container layout-px-spacing">
        <div class="container">

            <div id="navSection" data-spy="affix" class="nav sidenav">
                <div class="sidenav-content">
                    <a href="#tableSimple" class="active nav-link">Tahun Ajaran</a>
                    <a href="<?php echo e(route('majors.index')); ?>" class="nav-link">Jurusan</a>
                    <a href="<?php echo e(route('levels.index')); ?>" class="nav-link">Tingkat</a>
                    <a href="#tableDark" class="nav-link">Rombel</a>
                    <a href="#tableCaption" class="nav-link">Mata Pelajaran</a>
                </div>
            </div>

            <div class="row layout-top-spacing">
                <?php echo $__env->yieldContent('master'); ?>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin.v_main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sdn1kalibagorkbm/public_html/e-raport/resources/views/layout/admin/v_master.blade.php ENDPATH**/ ?>