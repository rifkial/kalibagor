<?php $__env->startSection('content'); ?>
    <?php $__env->startPush('styles'); ?>
        <?php echo $__env->make('package.loader.loader_css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('package.bootstrap-select.bootstrap-select_css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('asset/custom/account-setting.css')); ?>">
    <?php $__env->stopPush(); ?>
    <div class="layout-px-spacing">
        <div class="middle-content container-xxl p-0">

            <div class="page-meta mt-3">
                <nav class="breadcrumb-style-one" aria-label="breadcrumb">
                    <ol class="breadcrumb bg-transparent">
                        <li class="breadcrumb-item"><a href="#">User</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('users.index')); ?>">Siswa</a></li>
                        <li class="breadcrumb-item active" aria-current="page"><?php echo e(isset($teacher) ? 'Edit' : 'Tambah'); ?>

                        </li>
                    </ol>
                </nav>
            </div>
            <form
                action="<?php echo e(route('basic_competencies.storeOrUpdate', ['id' => isset($basic_competency) ? $basic_competency->id : null])); ?>"
                method="POST">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 layout-spacing">
                        <div class="info widget-content widget-content-area ecommerce-create-section">
                            <h6 class=""><?php echo e(session('title')); ?></h6>
                            <?php if(Auth::guard('teacher')->check()): ?>
                                <input type="hidden" name="id_course" value="<?php echo e(session('teachers.id_course')); ?>">
                                <input type="hidden" name="id_level" value="<?php echo e(session('teachers.id_level')); ?>">
                            <?php else: ?>
                                <div class="form-row">
                                    <div class="form-group col-md-6">
                                        <label for="inputEmail4">Mapel</label>
                                        <select name="id_course" id="" class="form-control selectpicker"
                                            data-live-search="true">
                                            <option value="" selected disabled>Pilih Mapel</option>
                                            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($course->id); ?>"
                                                    <?php echo e(isset($basic_competency) && old('id_course', $basic_competency->id_course) == $course->id ? 'selected' : (old('id_course') == $course->id ? 'selected' : '')); ?>>
                                                    <?php echo e($course->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="inputPassword4">Tingkat</label>
                                        <select name="id_level" id="id_level" class="form-control">
                                            <option value="" selected disabled>Pilih Tingkat</option>
                                            <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($level->id); ?>"
                                                    <?php echo e(isset($basic_competency) && old('id_level', $basic_competency->id_level) == $level->id ? 'selected' : (old('id_level') == $level->id ? 'selected' : '')); ?>>
                                                    <?php echo e($level->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['id_level'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <?php
                                if (isset($basic_competency)) {
                                    $name = json_decode($basic_competency->name);
                                }
                            ?>
                            <div class="form-group">
                                <label for="profession">Kode Kompetensi Dasar</label>
                                <input type="text" class="form-control" name="code"
                                    placeholder="Kode Kompetensi Dasar"
                                    value="<?php echo e(isset($basic_competency) ? old('code', $name->code) : old('code')); ?>">
                            </div>
                            <div class="form-group">
                                <label for="profession">Kompetensi Dasar</label>
                                <textarea name="name" rows="3" class="form-control" placeholder="Masukan Kompetensi Dasar"><?php echo e(isset($basic_competency) ? old('name', $name->name) : old('name')); ?></textarea>
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
        <div class="account-settings-footer">

            <div class="as-footer-container">

                <button id="multiple-reset" class="btn btn-warning">Reset All</button>
                <div class="blockui-growl-message">
                    <i class="flaticon-double-check"></i>&nbsp; Settings Saved Successfully
                </div>


                <button class="btn btn-primary d-none" id="btnLoader">
                    <div class="spinner-grow text-white mr-2 align-self-center loader-sm">
                        Loading...</div>
                    Loading
                </button>
                <button class="btn btn-primary" id="btnSubmit" onclick="submitForm()">Simpan
                    Data</button>
            </div>

        </div>
    </div>


    <?php $__env->startPush('scripts'); ?>
        <?php echo $__env->make('package.bootstrap-select.bootstrap-select_js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <script>
            $(function() {
                $("form").submit(function() {
                    $('#btnLoader').removeClass('d-none');
                    $('#btnSubmit').addClass('d-none');
                });
            });

            function submitForm() {
                $('form').submit();
            }
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin.v_main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sdn1kalibagorkbm/public_html/e-raport/resources/views/content/basic_competencies/v_form_basic_competency.blade.php ENDPATH**/ ?>