<?php $__env->startSection('content'); ?>
    <?php $__env->startPush('styles'); ?>
        <?php echo $__env->make('package.loader.loader_css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('asset/custom/account-setting.css')); ?>">
    <?php $__env->stopPush(); ?>
    <div class="layout-px-spacing">
        <div class="middle-content container-xxl p-0">

            <div class="page-meta mt-3">
                <nav class="breadcrumb-style-one" aria-label="breadcrumb">
                    <ol class="breadcrumb bg-transparent">
                        <li class="breadcrumb-item"><a href="#">User</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('users.index')); ?>">Siswa</a></li>
                        <li class="breadcrumb-item active" aria-current="page">List</li>
                    </ol>
                </nav>
            </div>

            <div class="row" id="cancel-row">

                <div class="col-xl-12 col-lg-12 col-sm-12 layout-top-spacing layout-spacing">
                    <div class="statbox widget box box-shadow">
                        <div class="widget-header">
                            <div class="row">
                                <div class="col-xl-12 col-md-12 col-sm-12 col-12 d-flex justify-content-between">
                                    <h4><?php echo e(session('title')); ?></h4>
                                    <div class="form-group my-auto">
                                        <select name="id_school_year" class="form-control">
                                            <option value="" selected disabled>-- Pilih Tahun Ajaran --</option>
                                            <?php $__currentLoopData = $school_years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school_year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    $semester = substr($school_year->name, -1) == 1 ? 'Ganjil' : 'Genap';
                                                ?>
                                                <option value="<?php echo e($school_year->slug); ?>"
                                                    <?php echo e($school_year->slug == $_GET['year'] ? 'selected' : ''); ?>>
                                                    <?php echo e(substr($school_year->name, 0, 9) . ' ' . $semester); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <form action="<?php echo e(route('templates.updateOrCreate')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="widget-content widget-content-area br-8">
                                <table class="table dt-table-hover w-100">
                                    <thead>
                                        <tr>
                                            <th></th>
                                            <th>Jurusan</th>
                                            <th>Jenis</th>
                                            <th>Template</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $templates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $template): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($index + 1); ?></td>
                                                <td><?php echo e($template['major']); ?></td>
                                                <td>
                                                    <input type="hidden" name="id_school_year[]"
                                                        value="<?php echo e($template['id_school_year']); ?>">

                                                    <select name="type[]" class="form-control"
                                                        id="type_<?php echo e($index + 1); ?>">
                                                        <option value="" selected disabled>Pilih Jenis</option>
                                                        <option value="uts"
                                                            <?php echo e(old('type', $template['type']) == 'uts' ? 'selected' : (old('type') == 'uts' ? 'selected' : '')); ?>>
                                                            Penilaian Tengah Semester</option>
                                                        <option value="uas"
                                                            <?php echo e(old('type', $template['type']) == 'uas' ? 'selected' : (old('type') == 'uas' ? 'selected' : '')); ?>>
                                                            Penilaian Akhir Semester</option>
                                                    </select>
                                                    <?php $__errorArgs = ['type.' . $index];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </td>
                                                <td>
                                                    <input type="hidden" name="id_major[]"
                                                        value="<?php echo e($template['id_major']); ?>">
                                                    <select name="template[]" class="form-control"
                                                        id="template_<?php echo e($index + 1); ?>">
                                                        <option value="" selected disabled>Pilih Template</option>
                                                        
                                                        <option value="manual"
                                                            <?php echo e(old('template', $template['template']) == 'manual' ? 'selected' : (old('template') == 'manual' ? 'selected' : '')); ?>>
                                                            Input Manual</option>
                                                        <option value="manual2"
                                                            <?php echo e(old('template', $template['template']) == 'manual2' ? 'selected' : (old('template') == 'manual2' ? 'selected' : '')); ?>>
                                                            Input Manual V2</option>
                                                        <option value="k13"
                                                            <?php echo e(old('template', $template['template']) == 'k13' ? 'selected' : (old('template') == 'k13' ? 'selected' : '')); ?>>
                                                            Kurikulum 13</option>
                                                        <option value="merdeka"
                                                            <?php echo e(old('template', $template['template']) == 'merdeka' ? 'selected' : (old('template') == 'merdeka' ? 'selected' : '')); ?>>
                                                            Kurikulum Merdeka</option>
                                                    </select>
                                                    <?php $__errorArgs = ['template.' . $index];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </td>
                                                <td>
                                                    <a href="javascript:void(0);"
                                                        onclick="previewTemplate(<?php echo e($index + 1); ?>)"
                                                        data-toggle="tooltip" data-placement="top" title=""
                                                        data-original-title="Edit"><svg xmlns="http://www.w3.org/2000/svg"
                                                            width="24" height="24" viewBox="0 0 24 24" fill="none"
                                                            stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                                            stroke-linejoin="round"
                                                            class="feather feather-check-circle text-primary">
                                                            <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                                                            <polyline points="22 4 12 14.01 9 11.01"></polyline>
                                                        </svg>
                                                    </a>
                                                </td>

                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="account-settings-footer">

            <div class="as-footer-container">

                <button id="multiple-reset" class="btn btn-warning">Reset All</button>
                <div class="blockui-growl-message">
                    <i class="flaticon-double-check"></i>&nbsp; Settings Saved Successfully
                </div>


                <button class="btn btn-primary d-none" id="btnLoader">
                    <div class="spinner-grow text-white mr-2 align-self-center loader-sm">
                        Loading...</div>
                    Loading
                </button>
                <button class="btn btn-primary" id="btnSubmit" onclick="submitForm()">Simpan
                    Data</button>

            </div>

        </div>
    </div>
    <?php $__env->startPush('scripts'); ?>
        <script>
            $(function() {
                $("form").submit(function() {
                    $('#btnLoader').removeClass('d-none');
                    $('#btnSubmit').addClass('d-none');
                });
            });

            function submitForm() {
                $('form').submit();
            }

            function previewTemplate(params) {
                let template = $('#template_' + params).val();
                let type = $('#type_' + params).val();
                window.open('preview/sample?template=' + template + '&type=' + type, '_blank');
            }
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin.v_main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sdn1kalibagorkbm/public_html/e-raport/resources/views/content/setting/v_template.blade.php ENDPATH**/ ?>