<?php $__env->startSection('content'); ?>
    <?php $__env->startPush('styles'); ?>
        <?php echo $__env->make('package.loader.loader_css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('package.bootstrap-select.bootstrap-select_css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('asset/custom/account-setting.css')); ?>">
    <?php $__env->stopPush(); ?>
    <div class="layout-px-spacing">
        <div class="middle-content container-xxl p-0">
            <div class="page-meta mt-3">
                <nav class="breadcrumb-style-one" aria-label="breadcrumb">
                    <ol class="breadcrumb bg-transparent">
                        <li class="breadcrumb-item"><a href="#">Setelan</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Konfigurasi</li>
                    </ol>
                </nav>
            </div>

            <div class="row mb-4 layout-spacing layout-top-spacing">
                <div class="col-xl-12 col-lg-12 col-md-12 layout-spacing">
                    <div id="general-info" class="section general-info">
                        <div class="info">
                            <h6 class=""><?php echo e(session('title')); ?></h6>
                            <form action="">
                                <div class="form-row align-items-center justify-content-center">
                                    <div class="col-auto">
                                        <label class="sr-only" for="inlineFormInput">Tahun Ajaran</label>
                                        <select name="year" id="school_year" class="form-control">
                                            <option value="" selected disabled>Pilih Tahun Ajaran</option>
                                            <?php $__currentLoopData = $school_years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school_year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    $semester = substr($school_year->name, -1) == 1 ? 'Ganjil' : 'Genap';
                                                ?>
                                                <option value="<?php echo e($school_year->slug); ?>"
                                                    <?php echo e($_GET['year'] == $school_year->slug ? 'selected' : ''); ?>>
                                                    <?php echo e(substr($school_year->name, 0, 9) . ' ' . $semester); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-auto">
                                        <label class="sr-only" for="inlineFormInputGroup">Kelas</label>
                                        <select name="class" id="study_class" class="selectpicker form-control"
                                            data-live-search="true">
                                            <option value="">Pilih kelas</option>
                                            <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($class->slug); ?>"
                                                    <?php echo e(isset($_GET['class']) && $_GET['class'] == $class->slug ? 'selected' : ''); ?>>
                                                    <?php echo e($class->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-auto">
                                        <button type="submit" class="btn btn-primary">Cari</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-xl-12 col-lg-12 col-md-12 layout-spacing">
                    <form id="about" class="section about" action="<?php echo e(route('setting_scores.kkm.storeOrUpdate')); ?>"
                        method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="info">
                            <h5 class=""><?php echo e(Str::upper($name_class)); ?></h5>
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Mata Pelajaran</th>
                                        <th>Guru</th>
                                        <th>Semester</th>
                                        <th>KKM</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(empty($result)): ?>
                                    <tr>
                                        <td colspan="5" class="text-center">Data belum tersedia</td>
                                    </tr>
                                    <?php else: ?>
                                        <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $kkm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($index + 1); ?></td>
                                                <td><?php echo e($kkm['course']); ?></td>
                                                <td><?php echo e($kkm['teacher']); ?></td>
                                                <td><?php echo e($kkm['school_year']); ?></td>
                                                <td>
                                                    <input type="hidden" name="id_course[]"
                                                        value="<?php echo e($kkm['id_course']); ?>">
                                                    <input type="hidden" name="id_study_class[]"
                                                        value="<?php echo e($kkm['id_study_class']); ?>">
                                                    <input type="hidden" name="id_school_year[]"
                                                        value="<?php echo e($kkm['id_school_year']); ?>">
                                                    <input type="number" name="score[]" class="form-control"
                                                        value="<?php echo e(old('score.' . $index, $kkm['score'])); ?>">
                                                    <?php $__errorArgs = ['score.' . $index];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="account-settings-footer">

            <div class="as-footer-container">

                <button id="multiple-reset" class="btn btn-warning">Reset All</button>
                <div class="blockui-growl-message">
                    <i class="flaticon-double-check"></i>&nbsp; Settings Saved Successfully
                </div>


                <button class="btn btn-primary d-none" id="btnLoader">
                    <div class="spinner-grow text-white mr-2 align-self-center loader-sm">
                        Loading...</div>
                    Loading
                </button>
                <button class="btn btn-primary" id="btnSubmit" onclick="submitForm()">Simpan
                    Data</button>

            </div>

        </div>
    </div>


    <?php $__env->startPush('scripts'); ?>
        <?php echo $__env->make('package.bootstrap-select.bootstrap-select_js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <script>
            $(function() {
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });

                $("#about").submit(function() {
                    $('#btnLoader').removeClass('d-none');
                    $('#btnSubmit').addClass('d-none');
                });
            });

            function submitForm() {
                $('#about').submit();
            }
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin.v_main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sdn1kalibagorkbm/public_html/e-raport/resources/views/content/setting_scores/v_kkm.blade.php ENDPATH**/ ?>