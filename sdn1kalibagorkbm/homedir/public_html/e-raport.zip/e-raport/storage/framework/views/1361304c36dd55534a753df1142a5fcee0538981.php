<?php $__env->startSection('content'); ?>
    <div class="layout-px-spacing">
        <div class="middle-content container-xxl p-0">

            <div class="page-meta mt-3">
                <nav class="breadcrumb-style-one" aria-label="breadcrumb">
                    <ol class="breadcrumb bg-transparent">
                        <li class="breadcrumb-item"><a href="#">User</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('users.index')); ?>">Siswa</a></li>
                        <li class="breadcrumb-item active" aria-current="page">List</li>
                    </ol>
                </nav>
            </div>

            <div class="row" id="cancel-row">

                <div class="col-xl-12 col-lg-12 col-sm-12 layout-top-spacing layout-spacing">
                    <div class="statbox widget box box-shadow">
                        <div class="widget-header">
                            <div class="row">
                                <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                                    <h4><?php echo e(session('title')); ?></h4>
                                </div>
                            </div>
                        </div>
                        <form action="<?php echo e(route('setting_scores.pts_configurations.storeOrUpdate')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="widget-content widget-content-area br-8">
                                <table class="table dt-table-hover w-100">
                                    <thead>
                                        <tr>
                                            <th></th>
                                            <th>Tahun Ajaran</th>
                                            <th>Semester</th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $school_years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school_year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td><?php echo e(substr($school_year->name, 0, 9)); ?> <?php if($school_year->status == 1): ?>
                                                        <div class="badge badge-success">Sekarang</div>
                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo e(substr($school_year->name, -1) == 1 ? 'Ganjil' : 'Genap'); ?></td>
                                                <td>
                                                    <?php if($school_year->score == true): ?>
                                                        <a target="_blank" href="<?php echo e(route('previews.print', $school_year->slug)); ?>">Lihat raport</a>
                                                    <?php else: ?>
                                                        <span class="text-danger">Nilai belum diinput</span>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <?php $__env->startPush('scripts'); ?>
        <script>
            $(function() {
                $("form").submit(function() {
                    $('#btnLoader').removeClass('d-none');
                    $('#btnSubmit').addClass('d-none');
                });
            });

            function submitForm() {
                $('form').submit();
            }
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin.v_main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sdn1kalibagorkbm/public_html/e-raport/resources/views/content/previews/v_preview.blade.php ENDPATH**/ ?>