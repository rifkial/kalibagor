<script src="<?php echo e(asset('asset/js/jquery-3.1.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('asset/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('asset/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('asset/js/perfect-scrollbar.min.js')); ?>"></script>
<script src="<?php echo e(asset('asset/js/app.js')); ?>"></script>

<script>
    $(document).ready(function() {
        App.init();
    });
</script>
<script src="<?php echo e(asset('asset/js/custom.js')); ?>"></script>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldPushContent('scripts'); ?>
<?php /**PATH /home/sdn1kalibagorkbm/public_html/e-raport/resources/views/layout/admin/v_foot.blade.php ENDPATH**/ ?>