<?php $__env->startSection('content'); ?>
    <?php $__env->startPush('styles'); ?>
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('asset/custom/search.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('asset/custom/account-setting.css')); ?>">
        <style>
            .rounded-vertical-pills-icon .nav-pills a {
                -webkit-border-radius: 0.625rem !important;
                -moz-border-radius: 0.625rem !important;
                -ms-border-radius: 0.625rem !important;
                -o-border-radius: 0.625rem !important;
                border-radius: 0.625rem !important;
                background-color: #ffffff;
                border: solid 1px #e4e2e2;
                padding: 11px 23px;
                text-align: center;
                width: 100px;
                padding: 8px;
            }

            .rounded-vertical-pills-icon .nav-pills a svg {
                display: block;
                text-align: center;
                margin-bottom: 10px;
                margin-top: 5px;
                margin-left: auto;
                margin-right: auto;
            }

            .rounded-vertical-pills-icon .nav-pills .nav-link.active,
            .rounded-vertical-pills-icon .nav-pills .show>.nav-link {
                box-shadow: 0px 5px 15px 0px rgba(0, 0, 0, 0.3);
                background-color: #009688;
                border-color: transparent;
            }
        </style>
    <?php $__env->stopPush(); ?>
    <div class="layout-px-spacing">
        <div class="middle-content container-xxl p-0">

            <div class="page-meta mt-3">
                <nav class="breadcrumb-style-one" aria-label="breadcrumb">
                    <ol class="breadcrumb bg-transparent">
                        <li class="breadcrumb-item"><a href="#">User</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('users.index')); ?>">Siswa</a></li>
                        <li class="breadcrumb-item active" aria-current="page">List</li>
                    </ol>
                </nav>
            </div>

            <div class="row" id="cancel-row">

                <div class="col-xl-12 col-lg-12 col-sm-12 layout-top-spacing layout-spacing">
                    <div class="statbox widget box box-shadow">
                        <div class="row">
                            <div id="tabsVerticalWithIcon" class="col-lg-12 col-12">
                                <div class="statbox widget box box-shadow">
                                    <div class="widget-header">
                                        <div class="row">
                                            <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                                                <h4 class="text-capitalize"><?php echo e(session('title')); ?></h4>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="widget-content widget-content-area rounded-vertical-pills-icon">

                                        <div class="row mb-4 mt-3">
                                            <div class="col-sm-4 col-12">
                                                <div class="nav flex-column nav-pills mb-sm-0 mb-3"
                                                    id="rounded-vertical-pills-tab" role="tablist"
                                                    aria-orientation="vertical">
                                                    <?php $__currentLoopData = $extras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $extra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <a class="nav-link mb-2 <?php echo e($extra->slug == $slug ? 'active' : ''); ?> mx-auto"
                                                            id="rounded-vertical-pills-profile-tab"
                                                            href="<?php echo e(route('score_extras.index', $extra->slug)); ?>">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="24"
                                                                height="24" viewBox="0 0 24 24" fill="none"
                                                                stroke="currentColor" stroke-width="2"
                                                                stroke-linecap="round" stroke-linejoin="round">
                                                                <line x1="12" y1="2" x2="12"
                                                                    y2="6"></line>
                                                                <line x1="12" y1="18" x2="12"
                                                                    y2="22"></line>
                                                                <line x1="4.93" y1="4.93" x2="7.76"
                                                                    y2="7.76"></line>
                                                                <line x1="16.24" y1="16.24" x2="19.07"
                                                                    y2="19.07"></line>
                                                                <line x1="2" y1="12" x2="6"
                                                                    y2="12"></line>
                                                                <line x1="18" y1="12" x2="22"
                                                                    y2="12"></line>
                                                                <line x1="4.93" y1="19.07" x2="7.76"
                                                                    y2="16.24"></line>
                                                                <line x1="16.24" y1="7.76" x2="19.07"
                                                                    y2="4.93"></line>
                                                            </svg> <?php echo e($extra->name); ?></a>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            </div>

                                            <div class="col-sm-8 col-12">
                                                <div class="tab-content" id="rounded-vertical-pills-tabContent">
                                                    <div class="tab-pane fade show active" id="rounded-vertical-pills-home"
                                                        role="tabpanel" aria-labelledby="rounded-vertical-pills-home-tab">
                                                        <div class="search-input-group-style input-group mb-3">
                                                            <div class="input-group-prepend">
                                                                <span class="input-group-text" id="basic-addon1"><svg
                                                                        xmlns="http://www.w3.org/2000/svg" width="24"
                                                                        height="24" viewBox="0 0 24 24" fill="none"
                                                                        stroke="currentColor" stroke-width="2"
                                                                        stroke-linecap="round" stroke-linejoin="round"
                                                                        class="feather feather-search">
                                                                        <circle cx="11" cy="11"
                                                                            r="8"></circle>
                                                                        <line x1="21" y1="21"
                                                                            x2="16.65" y2="16.65"></line>
                                                                    </svg></span>
                                                            </div>
                                                            <input type="text" id="input-search" class="form-control"
                                                                placeholder="Let's find your question in fast way"
                                                                aria-label="Username" aria-describedby="basic-addon1">
                                                        </div>
                                                        <form action="<?php echo e(route('score_extras.storeOrUpdate', $slug)); ?>"
                                                            method="post">
                                                            <?php echo csrf_field(); ?>
                                                            <div class="table-responsive">
                                                                <input type="hidden" name="id_extra"
                                                                    value="<?php echo e($detail_extra['id']); ?>">
                                                                <table class="table table-bordered table-hover">
                                                                    <thead>
                                                                        <tr>
                                                                            <th class="align-middle">No</th>
                                                                            <th class="align-middle">Siswa</th>
                                                                            <th class="align-middle text-center">NIS</th>
                                                                            <th class="align-middle">Status Naik</th>
                                                                            <th class="align-middle">Deskripsi</th>
                                                                        </tr>

                                                                    </thead>
                                                                    <tbody id="student-table">
                                                                        <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <tr>
                                                                                <td><?php echo e($index + 1); ?></td>
                                                                                <td>
                                                                                    <div class="d-flex">
                                                                                        <div
                                                                                            class="usr-img-frame mr-2 rounded-circle">
                                                                                            <img alt="avatar"
                                                                                                class="img-fluid rounded-circle"
                                                                                                src="<?php echo e($student['file'] != null ? asset($row['file']) : asset('asset/img/90x90.jpg')); ?>">
                                                                                        </div>
                                                                                        <p
                                                                                            class="align-self-center mb-0 admin-name">
                                                                                            <?php echo e($student['name']); ?></p>
                                                                                    </div>
                                                                                </td>
                                                                                <input type="hidden"
                                                                                    name="id_student_class[]"
                                                                                    value="<?php echo e($student['id_student_class']); ?>">
                                                                                <td><?php echo e($student['nis']); ?></td>
                                                                                <td>
                                                                                    <select name="score[]"
                                                                                        class="form-control" <?php echo e($student['status_form'] == false ? 'disabled' : ''); ?>>
                                                                                        <option value="sangat_baik" <?php echo e($student['score'] == 'sangat_baik' ? 'selected' : ''); ?>>Sangat
                                                                                            Baik
                                                                                        </option>
                                                                                        <option value="baik" <?php echo e($student['score'] == 'baik' ? 'selected' : ''); ?>>Baik
                                                                                        </option>
                                                                                        <option value="cukup" <?php echo e($student['score'] == 'cukup' ? 'selected' : ''); ?>>Cukup
                                                                                        </option>
                                                                                        <option value="kurang" <?php echo e($student['score'] == 'kurang' ? 'selected' : ''); ?>>Kurang
                                                                                        </option>
                                                                                    </select>
                                                                                    <?php $__errorArgs = ['score.' . $index];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                        <div class="invalid-feedback d-block">
                                                                                            <?php echo e($message); ?></div>
                                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                                </td>
                                                                                <td>
                                                                                    <textarea name="description[]" rows="2" class="form-control" <?php echo e($student['status_form'] == false ? 'readonly' : ''); ?>><?php echo e($student['description']); ?></textarea>
                                                                                    <?php $__errorArgs = ['description.' . $index];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                        <div class="invalid-feedback d-block">
                                                                                            <?php echo e($message); ?></div>
                                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                                </td>
                                                                            </tr>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="account-settings-footer">

            <div class="as-footer-container">

                <button id="multiple-reset" class="btn btn-warning">Reset All</button>
                <div class="blockui-growl-message">
                    <i class="flaticon-double-check"></i>&nbsp; Settings Saved Successfully
                </div>
                <button class="btn btn-primary d-none" id="btnLoader">
                    <div class="spinner-grow text-white mr-2 align-self-center loader-sm">
                        Loading...</div>
                    Loading
                </button>
                <button class="btn btn-primary" id="btnSubmit" onclick="submitForm()">Simpan
                    Data</button>

            </div>
        </div>
    </div>
    <?php $__env->startPush('scripts'); ?>
        <script>
            $(document).ready(function() {
                $('#input-search').on('keyup', function() {
                    var rex = new RegExp($(this).val(), 'i');
                    $('#student-table tr').hide();
                    $('#student-table tr').filter(function() {
                        return rex.test($(this).text());
                    }).show();
                });

                $("form").submit(function() {
                    $('#btnLoader').removeClass('d-none');
                    $('#btnSubmit').addClass('d-none');
                });
            });

            function submitForm() {
                $('form').submit();
            }
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin.v_main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sdn1kalibagorkbm/public_html/e-raport/resources/views/content/extracurriculars/v_score_extracurricular.blade.php ENDPATH**/ ?>