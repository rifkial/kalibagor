<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css"
    rel="stylesheet" type="text/css">
<?php /**PATH /home/sdn1kalibagorkbm/public_html/e-raport/resources/views/package/datepicker/datepicker_css.blade.php ENDPATH**/ ?>