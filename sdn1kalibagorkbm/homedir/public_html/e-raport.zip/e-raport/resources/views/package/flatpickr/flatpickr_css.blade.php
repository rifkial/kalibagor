<link rel="stylesheet" type="text/css" href="{{ asset('asset/css/flatpickr.css') }}">
<link rel="stylesheet" type="text/css" href="{{ asset('asset/custom/custom-flatpickr.css') }}">
