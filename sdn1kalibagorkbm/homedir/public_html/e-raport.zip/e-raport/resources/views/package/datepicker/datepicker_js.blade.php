<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>
<script>
    jQuery('.datepickerYear').datepicker({
        format: "yyyy",
        viewMode: "years",
        minViewMode: "years",
        language: "id",
        autoclose: true,
    });
</script>
