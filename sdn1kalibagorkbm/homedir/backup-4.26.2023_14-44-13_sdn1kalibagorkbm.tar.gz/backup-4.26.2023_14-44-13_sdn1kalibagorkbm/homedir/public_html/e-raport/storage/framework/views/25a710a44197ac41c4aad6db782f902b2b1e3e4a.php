<?php $__env->startSection('content'); ?>
    <?php $__env->startPush('styles'); ?>
        <?php echo $__env->make('package.loader.loader_css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('package.dropify.dropify_css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('package.switches.switches_css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('asset/custom/account-setting.css')); ?>">
    <?php $__env->stopPush(); ?>
    <div class="layout-px-spacing">
        <div class="middle-content container-xxl p-0">

            <div class="page-meta mt-3">
                <nav class="breadcrumb-style-one" aria-label="breadcrumb">
                    <ol class="breadcrumb bg-transparent">
                        <li class="breadcrumb-item"><a href="#">User</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('users.index')); ?>">Siswa</a></li>
                        <li class="breadcrumb-item active" aria-current="page"><?php echo e(isset($teacher) ? 'Edit' : 'Tambah'); ?>

                        </li>
                    </ol>
                </nav>
            </div>
            <?php if(isset($user)): ?>
                <?php echo e(Form::model($user, ['route' => ['users.update', $user->slug], 'method' => 'patch', 'files' => true])); ?>

            <?php else: ?>
                <?php echo e(Form::open(['route' => 'users.store', 'files' => true])); ?>

            <?php endif; ?>
            <div class="row">
                <div class="col-xl-12 col-lg-12 col-md-12 layout-spacing">
                    <div class="info widget-content widget-content-area ecommerce-create-section">
                        <h6 class="">Informasi Umum</h6>
                        <div class="row">
                            <div class="col-lg-11 mx-auto">
                                <div class="row">
                                    <div class="col-xl-2 col-lg-12 col-md-4">
                                        <div class="upload mt-4 pr-md-4">
                                            <input type="file" id="input-file-max-fs" class="dropify"
                                                data-default-file="<?php echo e(asset('asset/img/200x200.jpg')); ?>"
                                                data-max-file-size="2M" />
                                            <p class="mt-2"><i class="flaticon-cloud-upload mr-1"></i> Upload Picture</p>
                                        </div>
                                        <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-xl-10 col-lg-12 col-md-8 mt-md-0 mt-4">
                                        <div class="form">
                                            <div class="row">
                                                <div class="col-sm-6">
                                                    <div class="form-group">
                                                        <label for="fullName">Nama Lengkap</label>
                                                        <input type="text" class="form-control" name="name"
                                                            placeholder="Nama Lengkap"
                                                            value="<?php echo e(isset($user) ? old('name', $user->name) : old('name')); ?>">
                                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>

                                                </div>
                                                <div class="col-sm-6">
                                                    <label class="dob-input">Tanggal Lahir</label>
                                                    <div class="d-sm-flex d-block">
                                                        <div class="form-group mr-1">
                                                            <select class="form-control" name="day"
                                                                id="exampleFormControlSelect1">
                                                                <option selected disabled>Hari</option>
                                                                <?php for($i = 1; $i <= 31; $i++): ?>
                                                                    <option value="<?php echo e($i); ?>"
                                                                        <?php echo e(isset($user) && old('day', date('d', strtotime($user->date_of_birth))) == $i ? 'selected' : (old('day') == $i ? 'selected' : '')); ?>>
                                                                        <?php echo e($i); ?>

                                                                    </option>
                                                                <?php endfor; ?>
                                                            </select>
                                                            <?php $__errorArgs = ['day'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                        <div class="form-group mr-1">
                                                            <select class="form-control" name="month">
                                                                <option selected disabled>Bulan</option>
                                                                <option value="01"
                                                                    <?php echo e(isset($user) && old('month', date('m', strtotime($user->date_of_birth))) == '01' ? 'selected' : (old('month') == '01' ? 'selected' : '')); ?>>
                                                                    Januari</option>
                                                                <option value="02"
                                                                    <?php echo e(isset($user) && old('month', date('m', strtotime($user->date_of_birth))) == '02' ? 'selected' : (old('month') == '02' ? 'selected' : '')); ?>>
                                                                    Februari</option>
                                                                <option value="03"
                                                                    <?php echo e(isset($user) && old('month', date('m', strtotime($user->date_of_birth))) == '03' ? 'selected' : (old('month') == '03' ? 'selected' : '')); ?>>
                                                                    Maret</option>
                                                                <option value="04"
                                                                    <?php echo e(isset($user) && old('month', date('m', strtotime($user->date_of_birth))) == '04' ? 'selected' : (old('month') == '04' ? 'selected' : '')); ?>>
                                                                    April</option>
                                                                <option value="05"
                                                                    <?php echo e(isset($user) && old('month', date('m', strtotime($user->date_of_birth))) == '05' ? 'selected' : (old('month') == '05' ? 'selected' : '')); ?>>
                                                                    Mei</option>
                                                                <option value="06"
                                                                    <?php echo e(isset($user) && old('month', date('m', strtotime($user->date_of_birth))) == '06' ? 'selected' : (old('month') == '06' ? 'selected' : '')); ?>>
                                                                    Juni</option>
                                                                <option value="07"
                                                                    <?php echo e(isset($user) && old('month', date('m', strtotime($user->date_of_birth))) == '07' ? 'selected' : (old('month') == '07' ? 'selected' : '')); ?>>
                                                                    Juli</option>
                                                                <option value="08"
                                                                    <?php echo e(isset($user) && old('month', date('m', strtotime($user->date_of_birth))) == '08' ? 'selected' : (old('month') == '08' ? 'selected' : '')); ?>>
                                                                    Agustus</option>
                                                                <option value="09"
                                                                    <?php echo e(isset($user) && old('month', date('m', strtotime($user->date_of_birth))) == '09' ? 'selected' : (old('month') == '09' ? 'selected' : '')); ?>>
                                                                    September</option>
                                                                <option value="10"
                                                                    <?php echo e(isset($user) && old('month', date('m', strtotime($user->date_of_birth))) == '10' ? 'selected' : (old('month') == '10' ? 'selected' : '')); ?>>
                                                                    Oktober</option>
                                                                <option value="11"
                                                                    <?php echo e(isset($user) && old('month', date('m', strtotime($user->date_of_birth))) == '11' ? 'selected' : (old('month') == '11' ? 'selected' : '')); ?>>
                                                                    November</option>
                                                                <option value="12"
                                                                    <?php echo e(isset($user) && old('month', date('m', strtotime($user->date_of_birth))) == '12' ? 'selected' : (old('month') == '12' ? 'selected' : '')); ?>>
                                                                    Desember</option>
                                                            </select>
                                                            <?php $__errorArgs = ['month'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                        <div class="form-group mr-1">
                                                            <select class="form-control" name="year">
                                                                <option selected disabled>Tahun</option>
                                                                <?php
                                                                    $current_year = (int) date('Y');
                                                                    $start_year = (int) date('Y') - 60;
                                                                ?>
                                                                <?php for($year = $current_year; $year >= $start_year; $year--): ?>
                                                                    <option value="<?php echo e($year); ?>"
                                                                        <?php echo e(isset($user) && old('year', date('Y', strtotime($user->date_of_birth))) == $year ? 'selected' : (old('year') == $year ? 'selected' : '')); ?>>
                                                                        <?php echo e($year); ?>

                                                                    </option>
                                                                <?php endfor; ?>
                                                            </select>
                                                            <?php $__errorArgs = ['year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label for="profession">Email</label>
                                                <input type="text" class="form-control" name="email"
                                                    placeholder="Email"
                                                    value="<?php echo e(isset($user) ? old('email', $user->email) : old('email')); ?>">
                                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <div class="row mb-4">
                <div class="col-xl-12 col-lg-12 col-md-12 layout-spacing">
                    <div class="info widget-content widget-content-area ecommerce-create-section">
                        <h6 class="">Informasi Tambahan</h6>
                        <div class="row">
                            <div class="col-md-11 mx-auto">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="phone">Telepon</label>
                                            <input type="text" class="form-control" name="phone" placeholder="Telepon"
                                                value="<?php echo e(isset($user) ? old('phone', $user->phone) : old('phone')); ?>">
                                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="country">Jenis Kelamin</label>
                                            <select class="form-control" name="gender">
                                                <option value="male">Laki - laki</option>
                                                <option value="female">Perempuan</option>
                                            </select>
                                            <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="address">NIS</label>
                                            <input type="text" class="form-control" name="nis" placeholder="NIS"
                                                value="<?php echo e(isset($user) ? old('nis', $user->nis) : old('nis')); ?>">
                                            <?php $__errorArgs = ['nis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="address">NISN</label>
                                            <input type="text" class="form-control" name="nisn" placeholder="NISN"
                                                value="<?php echo e(isset($user) ? old('nisn', $user->nisn) : old('nisn')); ?>">
                                            <?php $__errorArgs = ['nisn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="location">Agama</label>
                                            <select class="form-control" name="religion">
                                                <option value="islam">Islam</option>
                                                <option value="kristen">Kristen</option>
                                                <option value="hindu">Hindu</option>
                                                <option value="budha">Budha</option>
                                                <option value="katolik">Katolik</option>
                                                <option value="konghucu">Konghucu</option>
                                                <option value="lainnya">Lainnya</option>
                                            </select>
                                            <?php $__errorArgs = ['religion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="phone">Tempat Lahir</label>
                                            <input type="text" class="form-control" name="place_of_birth"
                                                placeholder="Tempat lahir"
                                                value="<?php echo e(isset($user) ? old('place_of_birth', $user->place_of_birth) : old('place_of_birth')); ?>">
                                            <?php $__errorArgs = ['place_of_birth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="email">Tahun Angkatan</label>
                                            <input type="text" class="form-control" name="entry_year"
                                                placeholder="Tahun Angkatan"
                                                value="<?php echo e(isset($user) ? old('entry_year', $user->entry_year) : old('entry_year')); ?>">
                                            <?php $__errorArgs = ['entry_year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="website1">Alamat</label>
                                            <input type="text" class="form-control" name="address"
                                                placeholder="Alamat"
                                                value="<?php echo e(isset($user) ? old('address', $user->address) : old('address')); ?>">
                                            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="password">Password</label>
                                            <div class="input-group">
                                                <input type="password" class="form-control" id="password"
                                                    placeholder="&#8226;&#8226;&#8226;&#8226;&#8226;" name="password">
                                                <button class="btn btn-outline-secondary password-toggle" type="button"
                                                    onclick="return showPassword('#password')">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                                        viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                                        stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                                        class="feather feather-eye">
                                                        <path
                                                            d="M22.239 11.984c-1.395-3.795-5.232-7.984-10.239-7.984s-8.844 4.189-10.239 7.984c1.395 3.795 5.232 7.984 10.239 7.984s8.844-4.189 10.239-7.984zm-10.239 5.016c-2.916 0-5.283-2.368-5.283-5.283s2.368-5.283 5.283-5.283 5.283 2.368 5.283 5.283-2.368 5.283-5.283 5.283z">
                                                        </path>
                                                        <circle cx="12" cy="12" r="2"></circle>
                                                    </svg>
                                                </button>
                                            </div>
                                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="password_confirmation">Konfirmasi Password</label>
                                            <div class="input-group">
                                                <input type="password" class="form-control" id="password_confirmation" placeholder="&#8226;&#8226;&#8226;&#8226;&#8226;" name="password_confirmation">
                                                <button class="btn btn-outline-secondary password-toggle" type="button" onclick="return showPassword('#confirm_password')">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-eye">
                                                        <path d="M22.239 11.984c-1.395-3.795-5.232-7.984-10.239-7.984s-8.844 4.189-10.239 7.984c1.395 3.795 5.232 7.984 10.239 7.984s8.844-4.189 10.239-7.984zm-10.239 5.016c-2.916 0-5.283-2.368-5.283-5.283s2.368-5.283 5.283-5.283 5.283 2.368 5.283 5.283-2.368 5.283-5.283 5.283z"></path>
                                                        <circle cx="12" cy="12" r="2"></circle>
                                                    </svg>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <?php echo e(Form::close()); ?>

        </div>
        <div class="account-settings-footer">

            <div class="as-footer-container">

                <button id="multiple-reset" class="btn btn-warning">Reset All</button>
                <div class="blockui-growl-message">
                    <i class="flaticon-double-check"></i>&nbsp; Settings Saved Successfully
                </div>


                <button class="btn btn-primary d-none" id="btnLoader">
                    <div class="spinner-grow text-white mr-2 align-self-center loader-sm">
                        Loading...</div>
                    Loading
                </button>
                <button class="btn btn-primary" id="btnSubmit" onclick="submitForm()">Simpan
                    Data</button>
            </div>

        </div>
    </div>
    <?php $__env->startPush('scripts'); ?>
        <?php echo $__env->make('package.dropify.dropify_js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <script>
            $(function() {
                $("form").submit(function() {
                    $('#btnLoader').removeClass('d-none');
                    $('#btnSubmit').addClass('d-none');
                });
            });

            function showPassword(element) {
                if ('password' == $(element).attr('type')) {
                    $(element).prop('type', 'text');
                } else {
                    $(element).prop('type', 'password');
                }
            }

            function submitForm() {
                $('form').submit();
            }
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin.v_main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sdn1kalibagorkbm/public_html/e-raport/resources/views/content/users/v_form_user.blade.php ENDPATH**/ ?>