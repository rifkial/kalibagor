<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('layout.admin.v_head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <link href="<?php echo e(asset('asset/custom/error.css')); ?>" rel="stylesheet" type="text/css" />

</head>

<body class="error404 text-center">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-4 mr-auto mt-5 text-md-left text-center">
                <a href="index.html" class="ml-md-5">
                    <img alt="image-404" src="<?php echo e(asset(session('logo'))); ?>" class="theme-logo">
                </a>
            </div>
        </div>
    </div>
    <div class="container-fluid error-content">
        <div class="">
            <h1 class="error-number">Error</h1>
            <p class="mini-text">Ooops!</p>
            <p class="error-text mb-4 mt-1"><?php echo e(session('message')); ?></p>
            <a href="<?php echo e(URL::previous()); ?>" class="btn btn-primary mt-5">Go Back</a>
        </div>
    </div>
    <?php echo $__env->make('layout.admin.v_foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH /home/sdn1kalibagorkbm/public_html/e-raport/resources/views/pages/v_error.blade.php ENDPATH**/ ?>