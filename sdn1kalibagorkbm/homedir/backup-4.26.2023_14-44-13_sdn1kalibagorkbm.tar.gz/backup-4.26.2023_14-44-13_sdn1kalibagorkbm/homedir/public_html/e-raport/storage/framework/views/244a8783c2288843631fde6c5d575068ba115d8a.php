<script src="<?php echo e(asset('asset/js/datatables.js')); ?>" defer></script>
<script src="<?php echo e(asset('asset/js/dataTables.buttons.min.js')); ?>" defer></script>
<?php /**PATH /home/sdn1kalibagorkbm/public_html/e-raport/resources/views/package/datatable/datatable_js.blade.php ENDPATH**/ ?>