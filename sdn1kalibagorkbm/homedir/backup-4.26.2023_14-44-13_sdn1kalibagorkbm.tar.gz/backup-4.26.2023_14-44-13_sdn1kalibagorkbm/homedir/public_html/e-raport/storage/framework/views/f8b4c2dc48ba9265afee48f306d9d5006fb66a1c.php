<script src="<?php echo e(asset('asset/js/flatpickr.js')); ?>"></script>
<script>
    flatpickr(document.getElementsByClassName('basicPicker'));
    flatpickr(".formatYear", {
        format: "yyyy",
        viewMode: "years",
        minViewMode: "years",
        language: "id",
        autoclose: true,
    });
</script>
<?php /**PATH /home/sdn1kalibagorkbm/public_html/e-raport/resources/views/package/flatpickr/flatpickr_js.blade.php ENDPATH**/ ?>