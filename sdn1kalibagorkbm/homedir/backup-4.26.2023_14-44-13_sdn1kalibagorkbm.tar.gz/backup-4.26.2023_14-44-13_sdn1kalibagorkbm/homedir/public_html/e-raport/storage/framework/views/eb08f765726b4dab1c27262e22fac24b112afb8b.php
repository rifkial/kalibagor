<link rel="stylesheet" type="text/css" href="<?php echo e(asset('asset/css/datatables.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('asset/custom/datatable-custom.css')); ?>">
<?php /**PATH /home/sdn1kalibagorkbm/public_html/e-raport/resources/views/package/datatable/datatable_css.blade.php ENDPATH**/ ?>