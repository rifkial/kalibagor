<?php $__env->startSection('content'); ?>
    <?php $__env->startPush('styles'); ?>
        <?php echo $__env->make('package.loader.loader_css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('package.datatable.datatable_css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('asset/custom/account-setting.css')); ?>">
    <?php $__env->stopPush(); ?>
    <div class="layout-px-spacing">
        <div class="middle-content container-xxl p-0">

            <div class="page-meta mt-3">
                <nav class="breadcrumb-style-one" aria-label="breadcrumb">
                    <ol class="breadcrumb bg-transparent">
                        <li class="breadcrumb-item"><a href="#">User</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('users.index')); ?>">Siswa</a></li>
                        <li class="breadcrumb-item active" aria-current="page">List</li>
                    </ol>
                </nav>
            </div>

            <div class="row" id="cancel-row">

                <div class="col-xl-12 col-lg-12 col-sm-12 layout-top-spacing layout-spacing">
                    <div class="statbox widget box box-shadow">
                        <div class="widget-header">
                            <div class="row">
                                <div class="col-xl-12 col-md-12 col-sm-12 col-12 d-flex justify-content-between">
                                    <h4><?php echo e(session('title')); ?></h4>
                                </div>
                            </div>
                        </div>
                        <form action="<?php echo e(route('setting_scores.score_competency.storeOrUpdate')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="widget-content widget-content-area br-8">
                                <div class="table-responsive">
                                    <table id="table-list" class="table dt-table-hover w-100">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Siswa</th>
                                                <th>NISN</th>
                                                <th>Nilai Akhir</th>
                                                <th>Tujuan Pembelajaran Tercapai</th>
                                                <th>Tujuan Pembelajaran Perlu Ditingkatkan</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($index + 1); ?></td>
                                                    <td>
                                                        <?php
                                                            $file = asset('asset/img/90x90.jpg');
                                                            if ($student['file'] != null) {
                                                                $file = asset($student['file']);
                                                            }
                                                        ?>
                                                        <div class="d-flex">
                                                            <div class="usr-img-frame mr-2 rounded-circle">
                                                                <img alt="avatar" class="img-fluid rounded-circle"
                                                                    src="<?php echo e($file); ?>">
                                                            </div>
                                                            <p class="align-self-center mb-0 admin-name">
                                                                <?php echo e($student['name']); ?></p>
                                                        </div>
                                                    </td>
                                                    <td><?php echo e($student['nisn']); ?></td>
                                                    <td><?php echo e($student['score']); ?></td>
                                                    <input type="hidden" name="id_student_class_<?php echo e($index + 1); ?>"
                                                        value="<?php echo e($student['id']); ?>">
                                                    <input type="hidden" name="count_each[]" value="<?php echo e($index + 1); ?>">
                                                    <td>
                                                        <?php $__currentLoopData = $student['competency_archieved']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $competency_archieved): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="form-group form-check pl-0 mb-0">
                                                                <div class="custom-control custom-checkbox checkbox-info">
                                                                    <input type="checkbox" class="custom-control-input"
                                                                        id="competency_achieved_<?php echo e($student['id'] . '_' . $competency_archieved['id']); ?>"
                                                                        name="competency_achieved_<?php echo e($index + 1); ?>[]"
                                                                        value="<?php echo e($competency_archieved['id']); ?>" <?php echo e($competency_archieved['checked'] == true ? 'checked' : ''); ?>>
                                                                    <label class="custom-control-label"
                                                                        for="competency_achieved_<?php echo e($student['id'] . '_' . $competency_archieved['id']); ?>"><?php echo e($competency_archieved['achievement']); ?></label>
                                                                </div>
                                                            </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </td>
                                                    <td>
                                                        <?php $__currentLoopData = $student['competency_improved']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $competency_improved): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="form-group form-check pl-0 mb-0">
                                                                <div class="custom-control custom-checkbox checkbox-info">
                                                                    <input type="checkbox" class="custom-control-input"
                                                                        id="competency_improved_<?php echo e($student['id'] . '_' . $competency_improved['id']); ?>"
                                                                        name="competency_improved_<?php echo e($index + 1); ?>[]"
                                                                        value="<?php echo e($competency_improved['id']); ?>" <?php echo e($competency_improved['checked'] == true ? 'checked' : ''); ?>>
                                                                    <label class="custom-control-label"
                                                                        for="competency_improved_<?php echo e($student['id'] . '_' . $competency_improved['id']); ?>"><?php echo e($competency_improved['achievement']); ?></label>
                                                                </div>
                                                            </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="account-settings-footer">

            <div class="as-footer-container">

                <button id="multiple-reset" class="btn btn-warning">Reset All</button>
                <div class="blockui-growl-message">
                    <i class="flaticon-double-check"></i>&nbsp; Settings Saved Successfully
                </div>


                <button class="btn btn-primary d-none" id="btnLoader">
                    <div class="spinner-grow text-white mr-2 align-self-center loader-sm">
                        Loading...</div>
                    Loading
                </button>
                <button class="btn btn-primary" id="btnSubmit" onclick="submitForm()">Simpan
                    Data</button>

            </div>

        </div>
    </div>
    <?php $__env->startPush('scripts'); ?>
        <?php echo $__env->make('package.datatable.datatable_js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <script>
            $(document).ready(function() {
                $("form").submit(function() {
                    $('#btnLoader').removeClass('d-none');
                    $('#btnSubmit').addClass('d-none');
                });
            });

            function submitForm() {
                $('form').submit();
            }
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin.v_main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sdn1kalibagorkbm/public_html/e-raport/resources/views/content/score_p5/v_score_competency.blade.php ENDPATH**/ ?>