<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('layout.admin.v_head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <link href="<?php echo e(asset('asset/css/form-1.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('asset/css/theme-checkbox-radio.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('asset/css/switches.css')); ?>" rel="stylesheet" type="text/css" />
    


</head>

<body class="form">
    <div class="form-container">
        <div class="form-form">
            <div class="form-form-wrap">
                <div class="form-container">
                    <div class="form-content">
                        <?php
                            $setting = json_decode(file_get_contents(storage_path('app/settings.json')), true);
                        ?>

                        <h1 class="">Log In to <a href="<?php echo e(route('first_page')); ?>"><span
                                    class="brand-name text-uppercase"><?php echo e(isset($setting['name_school']) ? $setting['name_school'] : 'E-Raport'); ?></span></a>
                        </h1>
                        <form class="text-left" action="<?php echo e(route('auth.verify')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form">

                                <div id="username-field" class="field-wrapper input">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                        viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                                        stroke-linecap="round" stroke-linejoin="round" class="feather feather-user">
                                        <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                                        <circle cx="12" cy="7" r="4"></circle>
                                    </svg>
                                    <input id="username" name="username" type="text" class="form-control"
                                        placeholder="Username" value="<?php echo e(old('username')); ?>">
                                    <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div id="password-field" class="field-wrapper input mb-2">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                        viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                                        stroke-linecap="round" stroke-linejoin="round" class="feather feather-lock">
                                        <rect x="3" y="11" width="18" height="11" rx="2"
                                            ry="2"></rect>
                                        <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                                    </svg>
                                    <input id="password" name="password" type="password" class="form-control"
                                        placeholder="Password">
                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="d-sm-flex justify-content-between">
                                    <div class="field-wrapper toggle-pass">
                                        <p class="d-inline-block">Show Password</p>
                                        <label class="switch s-primary">
                                            <input type="checkbox" id="toggle-password" class="d-none">
                                            <span class="slider round"></span>
                                        </label>
                                    </div>
                                    <div class="field-wrapper">
                                        <button type="submit" class="btn btn-primary" value="">Log In</button>
                                    </div>

                                </div>

                                <div class="field-wrapper text-center keep-logged-in">
                                    <div class="n-chk new-checkbox checkbox-outline-primary">
                                        <label class="new-control new-checkbox checkbox-outline-primary">
                                            <input type="checkbox" class="new-control-input">
                                            <span class="new-control-indicator"></span>Keep me logged in
                                        </label>
                                    </div>
                                </div>

                                <div class="field-wrapper">
                                    <a href="auth_pass_recovery.html" class="forgot-pass-link">Forgot Password?</a>
                                </div>

                            </div>
                        </form>
                        <p class="terms-conditions"><?php echo e(isset($setting['footer']) ? $setting['footer'] : '© 2020 All Rights Reserved. <a href="index.html">CORK</a> is a
                            product of Designreset.'); ?></p>

                    </div>
                </div>
            </div>
        </div>
        <div class="form-image">
            <div class="l-image"
                style="background-image: url(<?php echo e(isset($setting['logo']) ? asset($setting['logo']) : 'https://cdn.pixabay.com/photo/2015/12/10/16/39/shield-1086703_960_720.png'); ?>)">
            </div>
        </div>
    </div>
    <?php echo $__env->make('layout.admin.v_foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script src="<?php echo e(asset('asset/js/form-1.js')); ?>"></script>

</body>

</html>
<?php /**PATH /home/sdn1kalibagorkbm/public_html/e-raport/resources/views/content/auth/v_login.blade.php ENDPATH**/ ?>