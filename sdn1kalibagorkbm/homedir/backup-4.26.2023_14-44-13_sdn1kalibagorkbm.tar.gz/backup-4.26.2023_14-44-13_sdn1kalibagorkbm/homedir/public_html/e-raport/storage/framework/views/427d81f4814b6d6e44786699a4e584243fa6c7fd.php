<link rel="stylesheet" type="text/css" href="<?php echo e(asset('asset/custom/animate.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('asset/custom/custom-modal.css')); ?>">
<?php /**PATH /home/sdn1kalibagorkbm/public_html/e-raport/resources/views/package/modal/modal_css.blade.php ENDPATH**/ ?>