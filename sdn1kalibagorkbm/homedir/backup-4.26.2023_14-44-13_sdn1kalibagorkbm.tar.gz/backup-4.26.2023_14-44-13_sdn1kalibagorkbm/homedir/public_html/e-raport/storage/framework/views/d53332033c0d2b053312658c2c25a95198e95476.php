<script src="<?php echo e(asset('asset/js/quill.js')); ?>"></script>

<?php /**PATH /home/sdn1kalibagorkbm/public_html/e-raport/resources/views/package/editor/editor_js.blade.php ENDPATH**/ ?>