<?php $__env->startSection('master'); ?>
    <?php $__env->startPush('styles'); ?>
        <?php echo $__env->make('package.loader.loader_css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('package.switches.switches_css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->stopPush(); ?>
    <div id="basic" class="col-lg-12 layout-spacing">
        <div class="statbox widget box box-shadow">
            <div class="widget-header">
                <div class="row">
                    <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                        <h4><?php echo e(session('title')); ?></h4>
                    </div>
                </div>
            </div>
            <div class="widget-content widget-content-area">
                <?php if(isset($class)): ?>
                    <?php echo e(Form::model($class, ['route' => ['classes.update', $class->slug], 'method' => 'patch'])); ?>

                <?php else: ?>
                    <?php echo e(Form::open(['route' => 'classes.store'])); ?>

                <?php endif; ?>

                <div class="form-row mb-4">
                    <div class="form-group col-md-6">
                        <label for="inputEmail4">Jurusan</label>
                        <select name="id_major" class="form-control" required>
                            <option value="" selected disabled>-- Pilih Jurusan --</option>
                            <?php $__currentLoopData = $majors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($mj['id']); ?>"
                                    <?php echo e(isset($class) && old('id_major', $class->id_major) == $mj->id ? 'selected' : (old('id_major') == $mj->id ? 'selected' : '')); ?>>
                                    <?php echo e($mj['name']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['id_major'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="inputPassword4">Tingkat</label>
                        <select name="id_level" class="form-control" required>
                            <option value="" selected disabled>-- Pilih Tingkat --</option>
                            <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($lv['id']); ?>"
                                    <?php echo e(isset($class) && old('id_level', $class->id_level) == $lv->id ? 'selected' : (old('id_level') == $lv->id ? 'selected' : '')); ?>>
                                    <?php echo e($lv['name']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['id_level'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="form-row">
                    <div class="col-md-12 mb-1">
                        <label for="fullName">Nama</label>
                        <input type="text" class="form-control" placeholder="Nama Kelas" required
                            value="<?php echo e(isset($class) ? old('name', $class->name) : old('name')); ?>" name="name[]">
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="addonForm">
                </div>
                <?php if(!isset($class)): ?>
                    <div class="form-row">
                        <div class="col-md-12 mb-4">
                            <a href="javascript:void(0)" class="btn btn-sm btn-success" onclick="addRow()">Tambah Baris</a>
                        </div>
                    </div>
                <?php endif; ?>
                <button class="btn btn-primary mt-2 d-none" id="btnLoader">
                    <div class="spinner-grow text-white mr-2 align-self-center loader-sm">
                        Loading...</div>
                    Loading
                </button>
                <button class="btn btn-primary submit-fn mt-2" type="submit" id="btnSubmit">Simpan
                    Data</button>
                <?php echo e(Form::close()); ?>

            </div>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
        <script>
            $(function() {
                $("form").submit(function() {
                    $('#btnLoader').removeClass('d-none');
                    $('#btnSubmit').addClass('d-none');
                });

                $(document).on('click', '.btn-remove', function() {
                    var button_id = $(this).attr("id");
                    $('#row' + button_id + '').remove();
                });
            });

            var i = 1;

            function addRow() {
                i++;
                $('.addonForm').append(`
                <div class="form-row" id="row${i}">
                        <div class="col-md-12 mt-3 mb-1">
                            <label for="fullName">Nama</label>
                            <input type="text" class="form-control" placeholder="Nama Kelas" name="name[]" required>
                            <a href="javascript:void(0)" class="btn btn-sm btn-danger mt-1 btn-remove" id="${i}">Hapus</a>
                        </div>
                    </div>
                `);
            }
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin.v_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sdn1kalibagorkbm/public_html/e-raport/resources/views/content/classes/v_form_class.blade.php ENDPATH**/ ?>