<?php $__env->startSection('master'); ?>
    <?php $__env->startPush('styles'); ?>
        <?php echo $__env->make('package.loader.loader_css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('package.switches.switches_css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->stopPush(); ?>
    <div id="basic" class="col-lg-12 layout-spacing">
        <div class="statbox widget box box-shadow">
            <div class="widget-header">
                <div class="row">
                    <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                        <h4><?php echo e(session('title')); ?></h4>
                    </div>
                </div>
            </div>
            <div class="widget-content widget-content-area">
                <?php if(isset($level)): ?>
                    <?php echo e(Form::model($level, ['route' => ['levels.update', $level->slug], 'method' => 'patch'])); ?>

                <?php else: ?>
                    <?php echo e(Form::open(['route' => 'levels.store'])); ?>

                <?php endif; ?>
                <div class="form-row mb-4">
                    <div class="form-group col-md-8">
                        <label for="inputEmail4">Nama</label>
                        <input type="text" class="form-control" name="name" placeholder="Level"
                            value="<?php echo e(isset($level) ? old('name', $level->name) : old('name')); ?>">
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group col-md-4">
                        <label for="inputPassword4">Fase</label>
                        <input type="text" class="form-control" name="fase" placeholder="Fase"
                            value="<?php echo e(isset($level) ? old('fase', $level->fase) : old('fase')); ?>">
                        <?php $__errorArgs = ['fase'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <button class="btn btn-primary mt-2 d-none" id="btnLoader">
                    <div class="spinner-grow text-white mr-2 align-self-center loader-sm">
                        Loading...</div>
                    Loading
                </button>
                <button class="btn btn-primary submit-fn mt-2" type="submit" id="btnSubmit">Simpan
                    Data</button>
                <?php echo e(Form::close()); ?>

            </div>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
        <script>
            $(function() {
                $("form").submit(function() {
                    $('#btnLoader').removeClass('d-none');
                    $('#btnSubmit').addClass('d-none');
                });
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin.v_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sdn1kalibagorkbm/public_html/e-raport/resources/views/content/levels/v_form_level.blade.php ENDPATH**/ ?>