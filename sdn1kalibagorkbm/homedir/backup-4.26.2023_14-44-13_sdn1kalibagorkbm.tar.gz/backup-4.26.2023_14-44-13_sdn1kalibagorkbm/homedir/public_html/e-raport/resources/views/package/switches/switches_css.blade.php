<link rel="stylesheet" type="text/css" href="{{ asset('asset/css/switches.css') }}">
