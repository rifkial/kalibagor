<script src="{{ asset('asset/js/dropify.min.js') }}"></script>
<script>
    $('.dropify').dropify();
</script>
