<script src="{{ asset('asset/js/datatables.js') }}" defer></script>
<script src="{{ asset('asset/js/dataTables.buttons.min.js') }}" defer></script>
