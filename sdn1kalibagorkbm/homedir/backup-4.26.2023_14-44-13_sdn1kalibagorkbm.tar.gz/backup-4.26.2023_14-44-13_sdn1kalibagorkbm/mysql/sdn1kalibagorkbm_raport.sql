-- MySQL dump 10.13  Distrib 5.7.42, for Linux (x86_64)
--
-- Host: localhost    Database: sdn1kalibagorkbm_raport
-- ------------------------------------------------------
-- Server version	5.7.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `sdn1kalibagorkbm_raport`
--


--
-- Table structure for table `achievements`
--

DROP TABLE IF EXISTS `achievements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `achievements` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_student_class` bigint(20) DEFAULT NULL,
  `id_teacher` int(11) NOT NULL,
  `id_study_class` int(11) NOT NULL,
  `ranking` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `level` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_school_year` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `achievements`
--

LOCK TABLES `achievements` WRITE;
/*!40000 ALTER TABLE `achievements` DISABLE KEYS */;
/*!40000 ALTER TABLE `achievements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admins`
--

DROP TABLE IF EXISTS `admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admins` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` enum('male','female') COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `file` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `place_of_birth` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_ip` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `admins_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admins`
--

LOCK TABLES `admins` WRITE;
/*!40000 ALTER TABLE `admins` DISABLE KEYS */;
INSERT INTO `admins` (`id`, `slug`, `name`, `email`, `gender`, `phone`, `address`, `file`, `place_of_birth`, `date_of_birth`, `password`, `last_ip`, `last_login`, `status`, `remember_token`, `created_at`, `updated_at`, `deleted_at`) VALUES (1,'dejah-rau','Dejah Rau','admin@mail.com','female','+18578643978','643 Macie Drives Suite 620\nJakobville, KS 63672',NULL,'Cruzland','1984-11-03','$2y$10$Nf3EgaxpBK/mVlabPnOeie.osnlDvzDeDa8Obnffm4Th5yLA0rdia','147.238.23.192','2004-11-14 05:39:01',1,NULL,'2023-04-18 22:16:44','2023-04-18 22:16:45',NULL),(2,'ron-legros','Ron Legros','elton.hermiston@example.net','female','+15046617389','3101 Harber Springs Apt. 010\nZulaufbury, WV 60460-0544',NULL,'Stacyshire','1974-06-11','$2y$10$oXJ1xvJTl1sFbiK91V9oqeMg/HdPr4xHyO11T.4dox/xDptSGbkY6','95.239.248.136','2018-05-02 11:24:25',1,NULL,'2023-04-18 22:16:44','2023-04-18 22:16:45',NULL);
/*!40000 ALTER TABLE `admins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assesment_weightings`
--

DROP TABLE IF EXISTS `assesment_weightings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assesment_weightings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_teacher` int(11) NOT NULL,
  `id_course` int(11) NOT NULL,
  `id_study_class` int(11) NOT NULL,
  `id_school_year` int(11) NOT NULL,
  `formative_weight` int(11) DEFAULT NULL,
  `sumative_weight` int(11) DEFAULT NULL,
  `uts_weight` int(11) DEFAULT NULL,
  `uas_weight` int(11) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assesment_weightings`
--

LOCK TABLES `assesment_weightings` WRITE;
/*!40000 ALTER TABLE `assesment_weightings` DISABLE KEYS */;
INSERT INTO `assesment_weightings` (`id`, `slug`, `id_teacher`, `id_course`, `id_study_class`, `id_school_year`, `formative_weight`, `sumative_weight`, `uts_weight`, `uas_weight`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES (1,NULL,1,1,1,1,20,30,20,30,1,'2023-04-18 22:52:16','2023-04-18 22:52:16',NULL);
/*!40000 ALTER TABLE `assesment_weightings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attendance_scores`
--

DROP TABLE IF EXISTS `attendance_scores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attendance_scores` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_student_class` bigint(20) DEFAULT NULL,
  `id_school_year` int(11) NOT NULL,
  `ill` tinyint(4) NOT NULL DEFAULT '0',
  `excused` tinyint(4) NOT NULL DEFAULT '0',
  `unexcused` tinyint(4) NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attendance_scores`
--

LOCK TABLES `attendance_scores` WRITE;
/*!40000 ALTER TABLE `attendance_scores` DISABLE KEYS */;
/*!40000 ALTER TABLE `attendance_scores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attitude_grades`
--

DROP TABLE IF EXISTS `attitude_grades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attitude_grades` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` enum('social','spiritual') COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_student_class` bigint(20) DEFAULT NULL,
  `id_school_year` int(11) NOT NULL,
  `id_teacher` int(11) NOT NULL,
  `predicate` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attitudes` json NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attitude_grades`
--

LOCK TABLES `attitude_grades` WRITE;
/*!40000 ALTER TABLE `attitude_grades` DISABLE KEYS */;
/*!40000 ALTER TABLE `attitude_grades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attitudes`
--

DROP TABLE IF EXISTS `attitudes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attitudes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` enum('social','spiritual') COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attitudes`
--

LOCK TABLES `attitudes` WRITE;
/*!40000 ALTER TABLE `attitudes` DISABLE KEYS */;
INSERT INTO `attitudes` (`id`, `slug`, `type`, `name`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES (1,NULL,'social','Jujur, yaitu perilaku dapat dipercaya dalam perkataan, tindakan, dan pekerjaan',1,'2023-04-18 22:23:29','2023-04-18 22:23:29',NULL),(2,NULL,'social','Disiplin, yaitu tindakan yang menunjukkan perilaku tertib dan patuh pada berbagai ketentuan dan peraturan',1,'2023-04-18 22:23:29','2023-04-18 22:23:29',NULL),(3,NULL,'social','Tanggung jawab, yaitu sikap dan perilaku seseorang untuk melaksanakan tugas dan kewajibannya, yang seharusnya dia lakukan, terhadap diri sendiri, masyarakat, lingkungan (alam, sosial dan budaya), negara, dan Tuhan Yang Maha Esa',1,'2023-04-18 22:23:29','2023-04-18 22:23:29',NULL),(4,NULL,'spiritual','berdoa sebelum dan sesudah melakukan kegiatan',1,'2023-04-18 22:24:22','2023-04-18 22:24:22',NULL),(5,NULL,'spiritual','menjalankan ibadah sesuai dengan agama yang dianut',1,'2023-04-18 22:24:22','2023-04-18 22:24:22',NULL),(6,NULL,'spiritual','memberi salam pada saat awal dan akhir kegiatan',1,'2023-04-18 22:24:22','2023-04-18 22:24:22',NULL);
/*!40000 ALTER TABLE `attitudes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `basic_competencies`
--

DROP TABLE IF EXISTS `basic_competencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `basic_competencies` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_course` int(11) DEFAULT NULL,
  `id_level` int(11) DEFAULT NULL,
  `name` json DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `basic_competencies`
--

LOCK TABLES `basic_competencies` WRITE;
/*!40000 ALTER TABLE `basic_competencies` DISABLE KEYS */;
/*!40000 ALTER TABLE `basic_competencies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `competence_achievements`
--

DROP TABLE IF EXISTS `competence_achievements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `competence_achievements` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_type_competence` tinyint(4) DEFAULT NULL,
  `id_course` int(11) NOT NULL,
  `id_study_class` int(11) NOT NULL,
  `id_teacher` int(11) NOT NULL,
  `id_school_year` int(11) NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `achievement` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `competence_achievements`
--

LOCK TABLES `competence_achievements` WRITE;
/*!40000 ALTER TABLE `competence_achievements` DISABLE KEYS */;
/*!40000 ALTER TABLE `competence_achievements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `configs`
--

DROP TABLE IF EXISTS `configs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `configs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `report_date` date NOT NULL,
  `final_report_date` date NOT NULL,
  `pts_date` date NOT NULL,
  `last_pts_date` date NOT NULL,
  `headmaster` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nip_headmaster` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `signature` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_school_year` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configs`
--

LOCK TABLES `configs` WRITE;
/*!40000 ALTER TABLE `configs` DISABLE KEYS */;
/*!40000 ALTER TABLE `configs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `courses`
--

DROP TABLE IF EXISTS `courses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `courses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `group` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `courses`
--

LOCK TABLES `courses` WRITE;
/*!40000 ALTER TABLE `courses` DISABLE KEYS */;
INSERT INTO `courses` (`id`, `slug`, `code`, `name`, `group`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES (1,'bahasa-indonesia-cOCD0','BIND','Bahasa Indonesia','A',1,'2023-04-18 22:29:24','2023-04-18 22:29:24',NULL),(2,'matematika-pY5Gg','MTK','Matematika','A',1,'2023-04-18 22:29:35','2023-04-18 22:29:35',NULL),(3,'ilmu-pengetahuan-alam-AylE9','IPA','Ilmu Pengetahuan Alam','A',1,'2023-04-18 22:29:48','2023-04-18 22:29:48',NULL);
/*!40000 ALTER TABLE `courses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `covers`
--

DROP TABLE IF EXISTS `covers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `covers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sub_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `instruction` text COLLATE utf8mb4_unicode_ci,
  `left_logo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `right_logo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_school_year` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `covers`
--

LOCK TABLES `covers` WRITE;
/*!40000 ALTER TABLE `covers` DISABLE KEYS */;
/*!40000 ALTER TABLE `covers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `description_competences`
--

DROP TABLE IF EXISTS `description_competences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `description_competences` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `criteria` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `description_competences`
--

LOCK TABLES `description_competences` WRITE;
/*!40000 ALTER TABLE `description_competences` DISABLE KEYS */;
/*!40000 ALTER TABLE `description_competences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dimensions`
--

DROP TABLE IF EXISTS `dimensions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dimensions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dimensions`
--

LOCK TABLES `dimensions` WRITE;
/*!40000 ALTER TABLE `dimensions` DISABLE KEYS */;
INSERT INTO `dimensions` (`id`, `slug`, `name`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES (1,'beriman-bertakwa-kepada-tuhan-yang-maha-esa-dan-berakhlak-mulia','beriman, bertakwa kepada Tuhan Yang Maha Esa, dan berakhlak mulia',1,NULL,NULL,NULL),(2,'mandiri','mandiri',1,NULL,NULL,NULL),(3,'bergotong-royong','bergotong-royong',1,NULL,NULL,NULL),(4,'berkebinekaan-global','berkebinekaan global',1,NULL,NULL,NULL),(5,'bernalar-kritis','bernalar kritis',1,NULL,NULL,NULL),(6,'kreatif','kreatif',1,NULL,NULL,NULL);
/*!40000 ALTER TABLE `dimensions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements`
--

DROP TABLE IF EXISTS `elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elements` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_dimension` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements`
--

LOCK TABLES `elements` WRITE;
/*!40000 ALTER TABLE `elements` DISABLE KEYS */;
INSERT INTO `elements` (`id`, `slug`, `name`, `id_dimension`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES (1,'akhlak-beragama','akhlak beragama',1,1,NULL,NULL,NULL),(2,'akhlak-pribadi','akhlak pribadi',1,1,NULL,NULL,NULL),(3,'akhlak-kepada-manusia','akhlak kepada manusia',1,1,NULL,NULL,NULL),(4,'akhlak-kepada-alam','akhlak kepada alam',1,1,NULL,NULL,NULL),(5,'akhlak-bernegara','akhlak bernegara',1,1,NULL,NULL,NULL),(6,'pemahaman-diri-dan-situasi-yang-dihadapi','Pemahaman diri dan situasi yang dihadapi',2,1,NULL,NULL,NULL),(7,'regulasi-diri','Regulasi diri',2,1,NULL,NULL,NULL),(8,'kolaborasi','kolaborasi',3,1,NULL,NULL,NULL),(9,'kepedulian','kepedulian',3,1,NULL,NULL,NULL),(10,'berbagi','berbagi',3,1,NULL,NULL,NULL),(11,'mengenal-dan-menghargai-budaya','mengenal dan menghargai budaya',4,1,NULL,NULL,NULL),(12,'komunikasi-dan-interaksi-antar-budaya','Komunikasi dan interaksi antar budaya',4,1,NULL,NULL,NULL),(13,'refleksi-dan-tanggung-jawab-terhadap-pengalaman-kebinekaan','refleksi dan tanggung jawab terhadap pengalaman kebinekaan',4,1,NULL,NULL,NULL),(14,'berkeadilan-sosial','Berkeadilan Sosial',4,1,NULL,NULL,NULL),(15,'memperoleh-dan-memproses-informasi-dan-gagasan','Memperoleh dan memproses informasi dan gagasan',5,1,NULL,NULL,NULL),(16,'menganalisis-dan-mengevaluasi-penalaran','Menganalisis dan mengevaluasi penalaran',5,1,NULL,NULL,NULL),(17,'merefleksi-dan-mengevaluasi-pemikirannya-sendiri','Merefleksi dan mengevaluasi pemikirannya sendiri',5,1,NULL,NULL,NULL),(18,'menghasilkan-gagasan-yang-orisinal','Menghasilkan gagasan yang orisinal',6,1,NULL,NULL,NULL),(19,'menghasilkan-karya-dan-tindakan-yang-orisinal','Menghasilkan karya dan tindakan yang orisinal',6,1,NULL,NULL,NULL),(20,'memiliki-keluwesan-berpikir-dalam-mencari-alternatif-solusi-permasalahan','Memiliki keluwesan berpikir dalam mencari alternatif solusi permasalahan',6,1,NULL,NULL,NULL);
/*!40000 ALTER TABLE `elements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `extracurriculars`
--

DROP TABLE IF EXISTS `extracurriculars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `extracurriculars` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `person_responsible` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `student_classes` json DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `extracurriculars`
--

LOCK TABLES `extracurriculars` WRITE;
/*!40000 ALTER TABLE `extracurriculars` DISABLE KEYS */;
/*!40000 ALTER TABLE `extracurriculars` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `general_weightings`
--

DROP TABLE IF EXISTS `general_weightings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `general_weightings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` enum('uts','uas') COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_teacher` int(11) NOT NULL,
  `id_course` int(11) NOT NULL,
  `id_study_class` int(11) NOT NULL,
  `id_school_year` int(11) NOT NULL,
  `score_weight` int(11) DEFAULT NULL,
  `uts_weight` int(11) DEFAULT NULL,
  `uas_weight` int(11) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `general_weightings`
--

LOCK TABLES `general_weightings` WRITE;
/*!40000 ALTER TABLE `general_weightings` DISABLE KEYS */;
/*!40000 ALTER TABLE `general_weightings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kkms`
--

DROP TABLE IF EXISTS `kkms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kkms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_study_class` int(11) DEFAULT NULL,
  `id_course` int(11) DEFAULT NULL,
  `score` int(11) DEFAULT NULL,
  `id_school_year` int(11) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kkms`
--

LOCK TABLES `kkms` WRITE;
/*!40000 ALTER TABLE `kkms` DISABLE KEYS */;
/*!40000 ALTER TABLE `kkms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `letterheads`
--

DROP TABLE IF EXISTS `letterheads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `letterheads` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `text1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `text2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `text3` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `text4` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `text5` text COLLATE utf8mb4_unicode_ci,
  `left_logo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `right_logo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `letterheads`
--

LOCK TABLES `letterheads` WRITE;
/*!40000 ALTER TABLE `letterheads` DISABLE KEYS */;
/*!40000 ALTER TABLE `letterheads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `levels`
--

DROP TABLE IF EXISTS `levels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `levels` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fase` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `levels`
--

LOCK TABLES `levels` WRITE;
/*!40000 ALTER TABLE `levels` DISABLE KEYS */;
INSERT INTO `levels` (`id`, `slug`, `name`, `fase`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES (1,'x-uYh8H','X','D',1,'2023-04-18 22:27:03','2023-04-18 22:27:03',NULL),(2,'xi-QuCFg','XI','E',1,'2023-04-18 22:27:11','2023-04-18 22:27:11',NULL),(3,'xii-uTe5s','XII','E',1,'2023-04-18 22:27:18','2023-04-18 22:27:18',NULL);
/*!40000 ALTER TABLE `levels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `majors`
--

DROP TABLE IF EXISTS `majors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `majors` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `majors`
--

LOCK TABLES `majors` WRITE;
/*!40000 ALTER TABLE `majors` DISABLE KEYS */;
INSERT INTO `majors` (`id`, `slug`, `name`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES (1,'pemesinan-q63ao','Pemesinan',1,'2023-04-18 22:26:12','2023-04-18 22:26:12',NULL),(2,'akuntansi-o6ExM','Akuntansi',1,'2023-04-18 22:26:19','2023-04-18 22:26:19',NULL),(3,'otomotif-kTp8n','Otomotif',1,'2023-04-18 22:26:25','2023-04-18 22:26:25',NULL),(4,'otomotif-AMLGG','Otomotif',1,'2023-04-18 22:26:26','2023-04-18 22:26:31','2023-04-18 22:26:31');
/*!40000 ALTER TABLE `majors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1),(4,'2019_12_14_000001_create_personal_access_tokens_table',1),(5,'2023_03_16_054436_create_admins_table',1),(6,'2023_03_20_014124_create_teachers_table',1),(7,'2023_03_20_021148_create_parents_table',1),(8,'2023_03_26_142733_create_majors_table',1),(9,'2023_03_27_013342_create_school_years_table',1),(10,'2023_03_27_035133_create_levels_table',1),(11,'2023_03_27_044600_create_study_classes_table',1),(12,'2023_03_27_075935_create_courses_table',1),(13,'2023_03_28_071607_create_subject_teachers_table',1),(14,'2023_03_30_075543_create_configs_table',1),(15,'2023_03_30_075559_create_covers_table',1),(16,'2023_03_31_040318_create_letterheads_table',1),(17,'2023_03_31_135434_create_dimensions_table',1),(18,'2023_03_31_140715_create_temas_table',1),(19,'2023_03_31_142146_create_p5_s_table',1),(20,'2023_03_31_142657_create_elements_table',1),(21,'2023_03_31_144148_create_sub_elements_table',1),(22,'2023_04_01_031743_create_student_classes_table',1),(23,'2023_04_02_155420_create_score_p5_s_table',1),(24,'2023_04_04_050228_create_type_competence_achievements_table',1),(25,'2023_04_04_051347_create_competence_achievements_table',1),(26,'2023_04_05_004651_create_description_competences_table',1),(27,'2023_04_05_023536_create_assesment_weightings_table',1),(28,'2023_04_05_065004_create_attitudes_table',1),(29,'2023_04_06_020238_create_extracurriculars_table',1),(30,'2023_04_06_061750_create_predicated_scores_table',1),(31,'2023_04_08_123340_create_pts_configurations_table',1),(32,'2023_04_08_143258_create_pas_configurations_table',1),(33,'2023_04_08_152453_create_kkms_table',1),(34,'2023_04_10_063724_create_template_configurations_table',1),(35,'2023_04_11_014135_create_score_merdekas_table',1),(36,'2023_04_13_011855_create_basic_competencies_table',1),(37,'2023_04_13_032749_create_score_kds_table',1),(38,'2023_04_13_061415_create_general_weightings_table',1),(39,'2023_04_14_060649_create_score_competencies_table',1),(40,'2023_04_15_044910_create_score_manuals_table',1),(41,'2023_04_17_031438_create_teacher_notes_table',1),(42,'2023_04_17_043734_create_achievements_table',1),(43,'2023_04_17_072545_create_attendance_scores_table',1),(44,'2023_04_17_153347_create_attitude_grades_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `p5_s`
--

DROP TABLE IF EXISTS `p5_s`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `p5_s` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_tema` int(11) NOT NULL,
  `id_subject_teacher` int(11) NOT NULL,
  `id_study_class` int(11) NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `sub_element` json DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `p5_s`
--

LOCK TABLES `p5_s` WRITE;
/*!40000 ALTER TABLE `p5_s` DISABLE KEYS */;
/*!40000 ALTER TABLE `p5_s` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `parents`
--

DROP TABLE IF EXISTS `parents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `parents` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nik` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `religion` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` enum('father','mother','guardian','other') COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `job` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_user` bigint(20) NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `parents`
--

LOCK TABLES `parents` WRITE;
/*!40000 ALTER TABLE `parents` DISABLE KEYS */;
/*!40000 ALTER TABLE `parents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pas_configurations`
--

DROP TABLE IF EXISTS `pas_configurations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pas_configurations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `average_daily_rate` int(11) DEFAULT NULL,
  `score_uts` int(11) DEFAULT NULL,
  `score_uas` int(11) DEFAULT NULL,
  `id_school_year` int(11) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pas_configurations`
--

LOCK TABLES `pas_configurations` WRITE;
/*!40000 ALTER TABLE `pas_configurations` DISABLE KEYS */;
/*!40000 ALTER TABLE `pas_configurations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `predicated_scores`
--

DROP TABLE IF EXISTS `predicated_scores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `predicated_scores` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `score` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `grade_weight` int(11) DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `predicated_scores`
--

LOCK TABLES `predicated_scores` WRITE;
/*!40000 ALTER TABLE `predicated_scores` DISABLE KEYS */;
/*!40000 ALTER TABLE `predicated_scores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pts_configurations`
--

DROP TABLE IF EXISTS `pts_configurations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pts_configurations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `average_daily_rate` int(11) DEFAULT NULL,
  `score_uts` int(11) DEFAULT NULL,
  `id_school_year` int(11) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pts_configurations`
--

LOCK TABLES `pts_configurations` WRITE;
/*!40000 ALTER TABLE `pts_configurations` DISABLE KEYS */;
/*!40000 ALTER TABLE `pts_configurations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `school_years`
--

DROP TABLE IF EXISTS `school_years`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `school_years` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '2',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `school_years`
--

LOCK TABLES `school_years` WRITE;
/*!40000 ALTER TABLE `school_years` DISABLE KEYS */;
INSERT INTO `school_years` (`id`, `slug`, `name`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES (1,'202320241-F1bLG','2023/20241',1,NULL,NULL,NULL),(2,'202320242-5WZNM','2023/20242',2,NULL,NULL,NULL);
/*!40000 ALTER TABLE `school_years` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `score_competencies`
--

DROP TABLE IF EXISTS `score_competencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `score_competencies` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_student_class` bigint(20) DEFAULT NULL,
  `id_teacher` int(11) NOT NULL,
  `id_course` int(11) NOT NULL,
  `id_study_class` int(11) NOT NULL,
  `id_school_year` int(11) NOT NULL,
  `competency_archieved` json DEFAULT NULL,
  `competency_improved` json DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `score_competencies`
--

LOCK TABLES `score_competencies` WRITE;
/*!40000 ALTER TABLE `score_competencies` DISABLE KEYS */;
/*!40000 ALTER TABLE `score_competencies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `score_kds`
--

DROP TABLE IF EXISTS `score_kds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `score_kds` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_school_year` int(11) DEFAULT NULL,
  `id_student_class` bigint(20) DEFAULT NULL,
  `assessment_score` json DEFAULT NULL,
  `averege_assesment` int(11) DEFAULT NULL,
  `skill_score` json DEFAULT NULL,
  `averege_skill` int(11) DEFAULT NULL,
  `score_uas` int(11) DEFAULT NULL,
  `score_uts` int(11) DEFAULT NULL,
  `final_assesment` int(11) DEFAULT NULL,
  `final_skill` int(11) DEFAULT NULL,
  `id_subject_teacher` int(11) DEFAULT NULL,
  `id_study_class` int(11) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `score_kds`
--

LOCK TABLES `score_kds` WRITE;
/*!40000 ALTER TABLE `score_kds` DISABLE KEYS */;
/*!40000 ALTER TABLE `score_kds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `score_manuals`
--

DROP TABLE IF EXISTS `score_manuals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `score_manuals` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_student_class` bigint(20) DEFAULT NULL,
  `id_teacher` int(11) NOT NULL,
  `id_course` int(11) NOT NULL,
  `id_study_class` int(11) NOT NULL,
  `id_school_year` int(11) NOT NULL,
  `assigment_grade` int(11) DEFAULT NULL,
  `daily_test_score` int(11) DEFAULT NULL,
  `score_uts` int(11) DEFAULT NULL,
  `score_uas` int(11) DEFAULT NULL,
  `score_final` int(11) DEFAULT NULL,
  `predicate` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `score_manuals`
--

LOCK TABLES `score_manuals` WRITE;
/*!40000 ALTER TABLE `score_manuals` DISABLE KEYS */;
/*!40000 ALTER TABLE `score_manuals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `score_merdekas`
--

DROP TABLE IF EXISTS `score_merdekas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `score_merdekas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_student_class` bigint(20) DEFAULT NULL,
  `id_course` int(11) DEFAULT NULL,
  `id_study_class` int(11) DEFAULT NULL,
  `id_teacher` int(11) DEFAULT NULL,
  `id_school_year` int(11) DEFAULT NULL,
  `score_formative` json DEFAULT NULL,
  `average_formative` int(11) DEFAULT NULL,
  `score_summative` json DEFAULT NULL,
  `average_summative` int(11) DEFAULT NULL,
  `score_uts` int(11) DEFAULT NULL,
  `score_uas` int(11) DEFAULT NULL,
  `final_score` int(11) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `score_merdekas`
--

LOCK TABLES `score_merdekas` WRITE;
/*!40000 ALTER TABLE `score_merdekas` DISABLE KEYS */;
/*!40000 ALTER TABLE `score_merdekas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `score_p5_s`
--

DROP TABLE IF EXISTS `score_p5_s`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `score_p5_s` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_student_class` bigint(20) DEFAULT NULL,
  `id_school_year` int(11) NOT NULL,
  `id_subject_teacher` bigint(20) NOT NULL,
  `score` json NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `score_p5_s`
--

LOCK TABLES `score_p5_s` WRITE;
/*!40000 ALTER TABLE `score_p5_s` DISABLE KEYS */;
/*!40000 ALTER TABLE `score_p5_s` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_classes`
--

DROP TABLE IF EXISTS `student_classes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student_classes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_student` bigint(20) DEFAULT NULL,
  `id_study_class` int(11) NOT NULL,
  `year` year(4) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_classes`
--

LOCK TABLES `student_classes` WRITE;
/*!40000 ALTER TABLE `student_classes` DISABLE KEYS */;
INSERT INTO `student_classes` (`id`, `slug`, `id_student`, `id_study_class`, `year`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES (3,'112023-m9Mdx',1,1,2023,1,'2023-04-18 22:49:19','2023-04-18 22:49:19',NULL),(4,'212023-3NBeq',2,1,2023,1,'2023-04-18 22:49:19','2023-04-18 22:49:19',NULL);
/*!40000 ALTER TABLE `student_classes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `study_classes`
--

DROP TABLE IF EXISTS `study_classes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `study_classes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_major` int(11) NOT NULL,
  `id_level` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `study_classes`
--

LOCK TABLES `study_classes` WRITE;
/*!40000 ALTER TABLE `study_classes` DISABLE KEYS */;
INSERT INTO `study_classes` (`id`, `slug`, `name`, `id_major`, `id_level`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES (1,'x-tpa-iYDZA','X TPA',1,1,1,'2023-04-18 22:27:48','2023-04-18 22:27:48',NULL),(2,'x-tpb-iXP7w','X TPB',1,1,1,'2023-04-18 22:27:48','2023-04-18 22:27:48',NULL),(3,'x-tpc-vGFIy','X TPC',1,1,1,'2023-04-18 22:27:48','2023-04-18 22:27:48',NULL),(4,'xi-tpa-Rf9j6','XI TPA',1,2,1,'2023-04-18 22:28:08','2023-04-18 22:28:08',NULL),(5,'xi-tpb-0Gxos','XI TPB',1,2,1,'2023-04-18 22:28:08','2023-04-18 22:28:08',NULL),(6,'xi-tpc-KCtTp','XI TPC',1,2,1,'2023-04-18 22:28:08','2023-04-18 22:28:08',NULL),(7,'xii-tpa-mdzQU','XII TPA',1,3,1,'2023-04-18 22:28:29','2023-04-18 22:28:29',NULL),(8,'xii-tpb-oXvf6','XII TPB',1,3,1,'2023-04-18 22:28:29','2023-04-18 22:28:29',NULL),(9,'xii-tpc-0L9kh','XII TPC',1,3,1,'2023-04-18 22:28:29','2023-04-18 22:28:29',NULL),(10,'x-moa-nKtXX','X MOA',3,1,1,'2023-04-18 22:30:24','2023-04-18 22:30:24',NULL),(11,'x-mob-sM5xA','X MOB',3,1,1,'2023-04-18 22:30:24','2023-04-18 22:30:24',NULL),(12,'x-moc-r8I5X','X MOC',3,1,1,'2023-04-18 22:30:24','2023-04-18 22:30:24',NULL),(13,'xi-moa-jY5LI','XI MOA',3,2,1,'2023-04-18 22:30:53','2023-04-18 22:30:53',NULL),(14,'xi-mob-DUCWL','XI MOB',3,2,1,'2023-04-18 22:30:53','2023-04-18 22:30:53',NULL),(15,'xi-moc-25KqV','XI MOC',3,2,1,'2023-04-18 22:30:53','2023-04-18 22:30:53',NULL),(16,'xii-moa-iFlpm','XII MOA',3,3,1,'2023-04-18 22:31:16','2023-04-18 22:31:16',NULL),(17,'xii-mob-Gp9OF','XII MOB',3,3,1,'2023-04-18 22:31:16','2023-04-18 22:31:16',NULL),(18,'xii-moc-MGspN','XII MOC',3,3,1,'2023-04-18 22:31:16','2023-04-18 22:31:16',NULL);
/*!40000 ALTER TABLE `study_classes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sub_elements`
--

DROP TABLE IF EXISTS `sub_elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sub_elements` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_dimension` int(11) NOT NULL,
  `id_element` int(11) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sub_elements`
--

LOCK TABLES `sub_elements` WRITE;
/*!40000 ALTER TABLE `sub_elements` DISABLE KEYS */;
INSERT INTO `sub_elements` (`id`, `slug`, `name`, `id_dimension`, `id_element`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES (1,'mengenal-dan-mencintai-tuhan-yang-maha-esa','Mengenal dan Mencintai Tuhan Yang Maha Esa',1,NULL,1,NULL,NULL,NULL),(2,'pemahaman-agama-kepercayaan','Pemahaman Agama/ Kepercayaan',1,NULL,1,NULL,NULL,NULL),(3,'pelaksanaan-ritual-ibadah','Pelaksanaan Ritual Ibadah',1,NULL,1,NULL,NULL,NULL),(4,'integritas','Integritas',1,NULL,1,NULL,NULL,NULL),(5,'merawat-diri-secara-fisik-mental-dan-spiritual','Merawat Diri secara Fisik, Mental, dan Spiritual',1,NULL,1,NULL,NULL,NULL),(6,'mengutamakan-persamaan-dengan-orang-lain-dan-menghargai-perbedaan','Mengutamakan persamaan dengan orang lain dan menghargai perbedaan',1,NULL,1,NULL,NULL,NULL),(7,'berempati-kepada-orang-lain','Berempati kepada orang lain',1,NULL,1,NULL,NULL,NULL),(8,'memahami-keterhu-bungan-ekosistem-bumi','Memahami Keterhu-bungan Ekosistem Bumi',1,NULL,1,NULL,NULL,NULL),(9,'menjaga-lingkungan-alam-sekitar','Menjaga Lingkungan Alam Sekitar',1,NULL,1,NULL,NULL,NULL),(10,'melaksanakan-hak-dan-kewajiban-sebagai-warga-negara-indonesia','Melaksanakan Hak dan Kewajiban sebagai Warga Negara Indonesia',1,NULL,1,NULL,NULL,NULL),(11,'mengenali-kualitas-dan-minat-diri-serta-tantangan-yang-dihadapi','Mengenali kualitas dan minat diri serta tantangan yang dihadapi',2,NULL,1,NULL,NULL,NULL),(12,'mengembangkan-refleksi-diri','Mengembangkan refleksi diri',2,NULL,1,NULL,NULL,NULL),(13,'regulasi-emosi','Regulasi emosi',2,NULL,1,NULL,NULL,NULL),(14,'penetapan-tujuan-belajar-prestasi-dan-pengembangan-diri-serta-rencana-strategis-untuk-mencapainya','Penetapan tujuan belajar, prestasi, dan pengembangan diri serta rencana strategis untuk mencapainya',2,NULL,1,NULL,NULL,NULL),(15,'menunjukkan-inisiatif-dan-bekerja-secara-mandiri','Menunjukkan inisiatif dan bekerja secara mandiri',2,NULL,1,NULL,NULL,NULL),(16,'mengembangkan-pengendalian-dan-disiplin-diri','Mengembangkan pengendalian dan disiplin diri',2,NULL,1,NULL,NULL,NULL),(17,'percaya-diri-tangguh-resilient-dan-adaptif','Percaya diri, tangguh (resilient), dan adaptif',2,NULL,1,NULL,NULL,NULL),(18,'kerja-sama','Kerja sama',3,NULL,1,NULL,NULL,NULL),(19,'komunikasi-untuk-mencapai-tujuan-bersama','Komunikasi untuk mencapai tujuan bersama',3,NULL,1,NULL,NULL,NULL),(20,'saling-ketergantungan-positif','Saling ketergantungan positif',3,NULL,1,NULL,NULL,NULL),(21,'koordinasi-sosial','Koordinasi Sosial',3,NULL,1,NULL,NULL,NULL),(22,'tanggap-terhadap-lingkungan-sosial','Tanggap terhadap lingkungan Sosial',3,NULL,1,NULL,NULL,NULL),(23,'persepsi-sosial','Persepsi sosial',3,NULL,1,NULL,NULL,NULL),(24,'mendalami-budaya-dan-identitas-budaya','Mendalami budaya dan identitas budaya',4,NULL,1,NULL,NULL,NULL),(25,'mengeksplorasi-dan-membandingkan-pengetahuan-budaya-kepercayaan-serta-praktiknya','mengeksplorasi dan membandingkan pengetahuan budaya, kepercayaan, serta praktiknya',4,NULL,1,NULL,NULL,NULL),(26,'menumbuhkan-rasa-menghormati-terhadap-keanekaragaman-budaya','Menumbuhkan rasa menghormati terhadap keanekaragaman budaya',4,NULL,1,NULL,NULL,NULL),(27,'berkomunikasi-antar-budaya','Berkomunikasi antar budaya',4,NULL,1,NULL,NULL,NULL),(28,'mempertimbangkan-dan-menumbuhkan-berbagai-perspektif','Mempertimbangkan dan menumbuhkan berbagai perspektif',4,NULL,1,NULL,NULL,NULL),(29,'refleksi-terhadap-pengalaman-kebinekaan','Refleksi terhadap pengalaman kebinekaan',4,NULL,1,NULL,NULL,NULL),(30,'menghilangkan-stereotip-dan-prasangka','Menghilangkan stereotip dan prasangka',4,NULL,1,NULL,NULL,NULL),(31,'menyelaraskan-perbedaan-budaya-aktif-membangun-masyarakat-yang-inklusif-adil-dan-berkelanjutan','Menyelaraskan perbedaan budaya Aktif membangun masyarakat yang inklusif, adil, dan berkelanjutan',4,NULL,1,NULL,NULL,NULL),(32,'berpartisipasi-dalam-proses-pengambilan-keputusan-bersama','Berpartisipasi dalam proses pengambilan keputusan bersama',4,NULL,1,NULL,NULL,NULL),(33,'memahami-peran-individu-dalam-demokrasi','Memahami peran individu dalam demokrasi ',4,NULL,1,NULL,NULL,NULL),(34,'mengajukan-pertanyaan','Mengajukan pertanyaan',5,NULL,1,NULL,NULL,NULL),(35,'mengidentifikasi-mengklarifikasi-dan-mengolah-informasi-dan-gagasan','Mengidentifikasi, mengklarifikasi, dan mengolah informasi dan gagasan',5,NULL,1,NULL,NULL,NULL),(36,'elemen-menganalisis-dan-mengevaluasi-penalaran-dan-prosedurnya','Elemen menganalisis dan mengevaluasi penalaran dan prosedurnya',5,NULL,1,NULL,NULL,NULL),(37,'merefleksi-dan-mengevaluasi-pemikirannya-sendiri','Merefleksi dan mengevaluasi pemikirannya sendiri',5,NULL,1,NULL,NULL,NULL),(38,'pelajar-kreatif-mampu-bereksperimen-dengan-berbagai-pilihan-secara-kreatif-ketika-menghadapi-perubahan-situasi-dan-kondisi','pelajar kreatif mampu bereksperimen dengan berbagai pilihan secara kreatif Ketika menghadapi perubahan situasi dan kondisi',6,NULL,1,NULL,NULL,NULL);
/*!40000 ALTER TABLE `sub_elements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subject_teachers`
--

DROP TABLE IF EXISTS `subject_teachers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subject_teachers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_teacher` int(11) NOT NULL,
  `id_course` int(11) NOT NULL,
  `id_school_year` int(11) NOT NULL,
  `id_study_class` json NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subject_teachers`
--

LOCK TABLES `subject_teachers` WRITE;
/*!40000 ALTER TABLE `subject_teachers` DISABLE KEYS */;
INSERT INTO `subject_teachers` (`id`, `slug`, `id_teacher`, `id_course`, `id_school_year`, `id_study_class`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES (1,NULL,1,1,1,'[\"1\", \"2\", \"3\", \"4\", \"5\", \"6\"]',1,'2023-04-18 22:35:21','2023-04-18 22:35:21',NULL);
/*!40000 ALTER TABLE `subject_teachers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teacher_notes`
--

DROP TABLE IF EXISTS `teacher_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `teacher_notes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_student_class` bigint(20) DEFAULT NULL,
  `id_school_year` int(11) NOT NULL,
  `id_teacher` int(11) DEFAULT NULL,
  `promotion` enum('Y','N') COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teacher_notes`
--

LOCK TABLES `teacher_notes` WRITE;
/*!40000 ALTER TABLE `teacher_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `teacher_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teachers`
--

DROP TABLE IF EXISTS `teachers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `teachers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nip` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nik` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nuptk` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` enum('male','female') COLLATE utf8mb4_unicode_ci NOT NULL,
  `religion` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `place_of_birth` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `type` enum('homeroom','teacher','other') COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_class` int(11) DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teachers`
--

LOCK TABLES `teachers` WRITE;
/*!40000 ALTER TABLE `teachers` DISABLE KEYS */;
INSERT INTO `teachers` (`id`, `slug`, `nip`, `nik`, `nuptk`, `name`, `gender`, `religion`, `file`, `phone`, `email`, `place_of_birth`, `date_of_birth`, `address`, `type`, `id_class`, `password`, `last_login`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES (1,'guru-1-pCzLS','242343545','213243435345','42343534546','Guru 1','female','islam',NULL,'089626040205','guru@mail.com','Kebumen','2009-04-15','Omnis eaque sed illo','homeroom',1,'$2y$10$Nf3EgaxpBK/mVlabPnOeie.osnlDvzDeDa8Obnffm4Th5yLA0rdia',NULL,1,'2023-04-18 22:33:33','2023-04-18 22:33:33',NULL);
/*!40000 ALTER TABLE `teachers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `temas`
--

DROP TABLE IF EXISTS `temas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `temas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` enum('paud','smp') COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `temas`
--

LOCK TABLES `temas` WRITE;
/*!40000 ALTER TABLE `temas` DISABLE KEYS */;
INSERT INTO `temas` (`id`, `slug`, `type`, `name`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES (1,'gaya-hidup-berkelanjutan','smp','Gaya Hidup Berkelanjutan',1,NULL,NULL,NULL),(2,'kearifan-lokal','smp','Kearifan Lokal',1,NULL,NULL,NULL),(3,'bhinneka-tunggal-ika','smp','Bhinneka Tunggal Ika',1,NULL,NULL,NULL),(4,'bangunlah-jiwa-dan-raganya','smp','Bangunlah Jiwa dan Raganya',1,NULL,NULL,NULL),(5,'suara-demokrasi','smp','Suara Demokrasi',1,NULL,NULL,NULL),(6,'rekayasa-dan-teknologi','smp','Rekayasa dan Teknologi',1,NULL,NULL,NULL),(7,'kewirausahaan','smp','Kewirausahaan',1,NULL,NULL,NULL),(8,'kebekerjaan','smp','Kebekerjaan',1,NULL,NULL,NULL),(9,'aku-sayang-bumi-gaya-hidup-berkelanjutan','paud','Aku Sayang Bumi \"Gaya Hidup Berkelanjutan\"',2,NULL,NULL,NULL),(10,'aku-cinta-indonesia-kearifan-lokal','paud','Aku Cinta Indonesia \"Kearifan Lokal\"',2,NULL,NULL,NULL),(11,'kita-semua-bersaudara-bhinneka-tunggal-ika','paud','Kita Semua Bersaudara \"Bhinneka Tunggal Ika\"',2,NULL,NULL,NULL),(12,'imajinasi-dan-kreativitasku-rekayasa-dan-teknologi','paud','Imajinasi dan Kreativitasku \"Rekayasa dan Teknologi\"',2,NULL,NULL,NULL),(13,'gaya-hidup-berkelanjutan','smp','Gaya Hidup Berkelanjutan',1,NULL,NULL,NULL),(14,'kearifan-lokal','smp','Kearifan Lokal',1,NULL,NULL,NULL),(15,'bhinneka-tunggal-ika','smp','Bhinneka Tunggal Ika',1,NULL,NULL,NULL),(16,'bangunlah-jiwa-dan-raganya','smp','Bangunlah Jiwa dan Raganya',1,NULL,NULL,NULL),(17,'suara-demokrasi','smp','Suara Demokrasi',1,NULL,NULL,NULL),(18,'rekayasa-dan-teknologi','smp','Rekayasa dan Teknologi',1,NULL,NULL,NULL),(19,'kewirausahaan','smp','Kewirausahaan',1,NULL,NULL,NULL),(20,'kebekerjaan','smp','Kebekerjaan',1,NULL,NULL,NULL),(21,'aku-sayang-bumi-gaya-hidup-berkelanjutan','paud','Aku Sayang Bumi \"Gaya Hidup Berkelanjutan\"',2,NULL,NULL,NULL),(22,'aku-cinta-indonesia-kearifan-lokal','paud','Aku Cinta Indonesia \"Kearifan Lokal\"',2,NULL,NULL,NULL),(23,'kita-semua-bersaudara-bhinneka-tunggal-ika','paud','Kita Semua Bersaudara \"Bhinneka Tunggal Ika\"',2,NULL,NULL,NULL),(24,'imajinasi-dan-kreativitasku-rekayasa-dan-teknologi','paud','Imajinasi dan Kreativitasku \"Rekayasa dan Teknologi\"',2,NULL,NULL,NULL);
/*!40000 ALTER TABLE `temas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `template_configurations`
--

DROP TABLE IF EXISTS `template_configurations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `template_configurations` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_major` int(11) DEFAULT NULL,
  `type` enum('uas','uts') COLLATE utf8mb4_unicode_ci NOT NULL,
  `template` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_school_year` int(11) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `template_configurations`
--

LOCK TABLES `template_configurations` WRITE;
/*!40000 ALTER TABLE `template_configurations` DISABLE KEYS */;
INSERT INTO `template_configurations` (`id`, `slug`, `id_major`, `type`, `template`, `id_school_year`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES (1,NULL,1,'uts','merdeka',1,1,'2023-04-18 22:34:29','2023-04-18 22:34:29',NULL),(2,NULL,2,'uts','manual',1,1,'2023-04-18 22:34:29','2023-04-18 22:34:29',NULL),(3,NULL,3,'uts','k16',1,1,'2023-04-18 22:34:29','2023-04-18 22:34:29',NULL);
/*!40000 ALTER TABLE `template_configurations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `type_competence_achievements`
--

DROP TABLE IF EXISTS `type_competence_achievements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `type_competence_achievements` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `type_competence_achievements`
--

LOCK TABLES `type_competence_achievements` WRITE;
/*!40000 ALTER TABLE `type_competence_achievements` DISABLE KEYS */;
INSERT INTO `type_competence_achievements` (`id`, `slug`, `name`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES (1,'capaian-pembelajaran','Capaian Pembelajaran ',1,NULL,NULL,NULL),(2,'tujuan-pembelajaran','Tujuan Pembelajaran ',1,NULL,NULL,NULL),(3,'alur-tujuan-pembelajaran','Alur Tujuan Pembelajaran ',1,NULL,NULL,NULL);
/*!40000 ALTER TABLE `type_competence_achievements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nis` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nisn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` enum('male','female') COLLATE utf8mb4_unicode_ci NOT NULL,
  `religion` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `place_of_birth` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entry_year` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `slug`, `nis`, `nisn`, `name`, `gender`, `religion`, `file`, `phone`, `email`, `place_of_birth`, `date_of_birth`, `address`, `password`, `entry_year`, `last_login`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES (1,'reed-ellison-sVIo6','Commodo dolorem eos','Dolor totam duis cum','Reed Ellison','male','islam',NULL,'089626040205','siswa@mail.com','Voluptatem tempor vo','2013-11-02','Proident qui quibus','$2y$10$.ar0N0H7TWqbmvEL6JL1f.ilPrL/YJCNDfBhSkgRnsYj2abRMLu0a','2010',NULL,1,'2023-04-18 22:42:35','2023-04-18 22:42:35',NULL),(2,'amelia-atkinson-skekz','Illum odit a ullamc','Qui dicta sed debiti','Amelia Atkinson','female','hindu',NULL,'089626040201','siswa1@mail.com','Ex aut reiciendis mo','1981-02-20','Eveniet occaecat id','$2y$10$XlVAWTyv1VSwWRObn4b9N.043toriYQygLOqreJGS4mqVtJ7CTMX2','2001',NULL,1,'2023-04-18 22:43:04','2023-04-18 22:43:04',NULL),(3,'mercedes-winters-b9w7W','Labore ipsum deserun','Fugiat elit facilis','Mercedes Winters','male','islam',NULL,'089626040202','siswa2@mail.com','Cupiditate officia a','1991-08-11','Et deserunt ab molli','$2y$10$sWC874Ts4DTpOcCw8sPfS.XqzJrsWYvFUaHIWXigPN1vBxmc6vyZa','2012',NULL,1,'2023-04-18 22:43:43','2023-04-18 22:43:43',NULL),(4,'vivian-mcdaniel-TaIPh','Incididunt et volupt','Qui sed quisquam sed','Vivian Mcdaniel','male','konghucu',NULL,'089626040204','siswa3@mail.com','Ex autem rem odit se','1987-01-28','Elit id ut eveniet','$2y$10$xBV67gxMOWtqYj42pXPcqOQmzFXkdoV28raCyP2eYlsGzuZowYTVi','1982',NULL,1,'2023-04-18 22:44:04','2023-04-18 22:44:04',NULL),(5,'graiden-hooper-xvG7Q','Ut tenetur reiciendi','Facere voluptatem na','Graiden Hooper','female','islam',NULL,'089626040206','siswa4@mail.com','Ea aperiam sed possi','1975-11-20','Vitae sed quo expedi','$2y$10$mpDQKKmhLhSQRUOFLpnb0.3QVZnS7wKIvC6kZRBJYgfNqgkkDNR1u','1980',NULL,1,'2023-04-18 22:44:26','2023-04-18 22:44:26',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'sdn1kalibagorkbm_raport'
--

--
-- Dumping routines for database 'sdn1kalibagorkbm_raport'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-26 14:44:14
