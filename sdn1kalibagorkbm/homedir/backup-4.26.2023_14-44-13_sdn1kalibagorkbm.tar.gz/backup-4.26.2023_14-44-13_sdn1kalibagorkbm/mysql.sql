-- cPanel mysql backup
GRANT USAGE ON *.* TO 'sdn1kalibagorkbm'@'172.31.16.240' IDENTIFIED BY PASSWORD '*A9083527F20411EFC9B9ADD93E0AEA16371D7A62';
GRANT ALL PRIVILEGES ON `sdn1kalibagorkbm\_raport`.* TO 'sdn1kalibagorkbm'@'172.31.16.240';
GRANT USAGE ON *.* TO 'sdn1kalibagorkbm'@'52.77.82.54' IDENTIFIED BY PASSWORD '*A9083527F20411EFC9B9ADD93E0AEA16371D7A62';
GRANT ALL PRIVILEGES ON `sdn1kalibagorkbm\_raport`.* TO 'sdn1kalibagorkbm'@'52.77.82.54';
GRANT USAGE ON *.* TO 'sdn1kalibagorkbm'@'admin.myschid.my.id' IDENTIFIED BY PASSWORD '*A9083527F20411EFC9B9ADD93E0AEA16371D7A62';
GRANT ALL PRIVILEGES ON `sdn1kalibagorkbm\_raport`.* TO 'sdn1kalibagorkbm'@'admin.myschid.my.id';
GRANT USAGE ON *.* TO 'sdn1kalibagorkbm'@'localhost' IDENTIFIED BY PASSWORD '*A9083527F20411EFC9B9ADD93E0AEA16371D7A62';
GRANT ALL PRIVILEGES ON `sdn1kalibagorkbm\_raport`.* TO 'sdn1kalibagorkbm'@'localhost';
GRANT USAGE ON *.* TO 'sdn1kalibagorkbm_userraport'@'172.31.16.240' IDENTIFIED BY PASSWORD '*2705A30177483A850032751AD07B600DD6AACB7E';
GRANT ALL PRIVILEGES ON `sdn1kalibagorkbm\_raport`.* TO 'sdn1kalibagorkbm_userraport'@'172.31.16.240';
GRANT USAGE ON *.* TO 'sdn1kalibagorkbm_userraport'@'52.77.82.54' IDENTIFIED BY PASSWORD '*2705A30177483A850032751AD07B600DD6AACB7E';
GRANT ALL PRIVILEGES ON `sdn1kalibagorkbm\_raport`.* TO 'sdn1kalibagorkbm_userraport'@'52.77.82.54';
GRANT USAGE ON *.* TO 'sdn1kalibagorkbm_userraport'@'admin.myschid.my.id' IDENTIFIED BY PASSWORD '*2705A30177483A850032751AD07B600DD6AACB7E';
GRANT ALL PRIVILEGES ON `sdn1kalibagorkbm\_raport`.* TO 'sdn1kalibagorkbm_userraport'@'admin.myschid.my.id';
GRANT USAGE ON *.* TO 'sdn1kalibagorkbm_userraport'@'localhost' IDENTIFIED BY PASSWORD '*2705A30177483A850032751AD07B600DD6AACB7E';
GRANT ALL PRIVILEGES ON `sdn1kalibagorkbm\_raport`.* TO 'sdn1kalibagorkbm_userraport'@'localhost';
